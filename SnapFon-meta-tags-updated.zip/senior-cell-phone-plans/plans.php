<?php
// Decision tree, plans page or lightbox?
chdir('../catalog');
include_once('includes/application_top.php'); 
if (DIR_FS_ROOT == 'DIR_FS_ROOT') {
  echo "<pre>\n";
  echo "CWD: " . getcwd() . "\n";
  die('Something about application_top.php failed to load.');
}
$common_price_details = 
'<span>
  all taxes and<br />
  fees included<br />
</span>
except TN residents';
$common_plan_details = 
'      <li>No Contract</li>
      <li>No Long Distance Charges</li>
      <li>No Roaming or Overage Charges</li>';
$plans = array(
  PLAN_BF_ID => array(
    'Name' => 'Basic Flex',
    'Price' => array(
      BF_PLAN_PRICE,
      "$common_price_details",
    ),
    'Details' => "<ul>
      <li><a onclick='\$flexInfo.dialog(\"open\");'>Additional Minutes 5&cent; or less</a></li>
$common_plan_details
    </ul>",
    'Minutes' => '<ul>
      <li>130 minutes</li>
      <li>Unlimited Rollover</li>
    </ul>',
    'Includes' => array(
      'ezProtection',
    ),
  ),
  PLAN_BU_ID => array(
    'Name' => 'Basic Unlimited',
    'Price' => array(
      BU_PLAN_PRICE,
      "$common_price_details",
    ),
    'Details' => "
      <ul>
        <li>Unlimited Texts</li>
$common_plan_details
      </ul>",
    'Minutes' => '<ul>
      <li>Unlimited</li>
    </ul>',
    'Includes' => array(
      'ezProtection',
    ),
  ),
  PLAN_PF_ID => array(
    'Name' => 'Premium Flex',
    'Price' => array(
      PF_PLAN_PRICE,
      "$common_price_details",
    ),
    'Details' => "<ul>
      <li><a onclick='\$flexInfo.dialog(\"open\");'>Additional Minutes 5&cent; or less</a></li>
$common_plan_details
    </ul>",
    'Minutes' => '<ul>
      <li>130 minutes</li>
      <li>Unlimited Rollover</li>
    </ul>',
    'Includes' => array(
      'ezProtection',
      'oneCall Mobile',
    ),
  ),
  PLAN_PU_ID => array(
    'Name' => 'Premium Unlimited',
    'Price' => array(
      PU_PLAN_PRICE,
      "$common_price_details",
    ),
    'Details' => "
      <ul>
        <li>Unlimited Texts</li>
$common_plan_details
      </ul>",
    'Minutes' => '<ul>
      <li>Unlimited</li>
    </ul>',
    'Includes' => array(
      'ezProtection',
      'oneCall Mobile',
    ),
  ),
);

$test = $_SERVER['SCRIPT_NAME'];
if (strpos($test, 'plans/index.php')) {
  // calls plans_head() and plans_script();
  $lightbox = false;
  plans_page();
} else {
  // Needs plans_head(); in calling page.
  $lightbox = true;
  plans_script();
  plans_lightbox();
}
// THE END

function sup_money($money) {
  $dollars_cents = explode('.', number_format($money, 2));
  return "{$dollars_cents[0]}<sup>.{$dollars_cents[1]}</sup>";
}

function show_plan($id) {
  global $plans, $mainSitePath, $request_type;
  // Split dollars and cents.
?>
      <div id='plan<?= $id; ?>'>
        <div class='plan'
            onclick='
            $(this).children(".voice_plan").children("span").toggle();
            $(this).parent().children(".plan_details").toggle();
        '>
          <div class='voice_plan'>
            <?= $plans[$id]['Name']; ?> <span>&#9656;</span><span style='display: none;'>&#9662;</span>
          </div><div class='minutes'><?= $plans[$id]['Minutes']; ?>
          </div><div class='includes'>
<?php
  foreach ($plans[$id]['Includes'] as $v) {
    echo '            ';
    switch ($v) {
      case 'ezProtection':
        echo "<img src='{$mainSitePath}images/ezprotection_shield.png' alt='$v'>";
        break;
      case 'oneCall Mobile':
        echo "<img src='{$mainSitePath}images/onecall_shield.png' alt='$v'>";
//        echo "<img src='{$mainSitePath}images/free-eztwo-icon.png' alt='$v'>";

        break;
      default:
        echo "$v<br />";
    }
  }
?>
          </div><div class='price'><span><sup>$</sup><?= sup_money($plans[$id]['Price'][0]); ?></span>
          </div><div class='button'>
            <span class='button'
              onClick="temp_id = <?= $id ?>; if (script_page == 'cart') { doAddItemFromWizard(temp_id, 'planpicker') } else { doGetActivationType(temp_id, 'planpicker') };"
            >Add to Cart</span>
          </div>
        </div>
        <div class='plan_details'>
          <div class='details'>
<?= $plans[$id]['Details']; ?>
          </div>
          <div class='includes'>
<?php
  foreach ($plans[$id]['Includes'] as $v) {
    echo '            ';
    switch ($v) {
      case 'ezProtection':
        echo "<a href='{$mainSitePath}services/handset_protection.php'>$v</a><br />";
        break;
      case 'oneCall Mobile':
        echo "<a href='{$mainSitePath}services/onecall_mobile.php'>$v</a><br />";
        break;
      default:
        echo "x$v<br />";
    }
  }
?>
          </div>
          <div class='price'>
<?= $plans[$id]['Price'][1]; ?>
          </div>
        </div>
      </div>
<?php
}

// Needs to be in the head
function plans_head() {
  global $mainSitePath, $request_type;
?>
<!-- plans_head() - START -->
    <link rel='stylesheet' type='text/css' href='<?= HTTP ?>://ajax.googleapis.com/ajax/libs/dojo/1.5/dojo/resources/dojo.css' />
    <link rel='stylesheet' type='text/css' href='<?= HTTP ?>://ajax.googleapis.com/ajax/libs/dojo/1.5/dijit/themes/claro/claro.css' />
    <style type='text/css'>
/* plans_header - START */
      #plans_header {
        position: relative;
        background-image: url();
        width: auto;
        height: auto;
      }
      #plans_header div {
        display: inline-block;
        width: auto;
        height: auto;
        margin: 0;
        padding: 0;
        top: 0;
      }
      #plans_header div.left {
        width: 800px;
        vertical-align: top;
      }
      #plans_header div.left p {
        font-size: 18px;
      }
      #plans_header div.right {
        width: 170px;
        text-align: center;
        padding-top: 1.5em;
      }
      #plans_header div.right img {
        display: inline-block;
      }
/* plans_header - END */
    </style>
<!-- plans_head() - END -->
<?php
}

// Show shared items of both Lightbox and Standalone
function plans_script() {
  global $mainSitePath, $lightbox, $request_type;
?>
<!-- plans_script() - START -->
    <?php // These should stay in for the pages that need ajax or dojo ?>
    <script src='<?= $mainSitePath ?>js/dojo.1.5.2/dojo/dojo.js' type='text/javascript'></script>
    <script type='text/javascript'>
      SCRIPT_NAME = '<?= $_SERVER['SCRIPT_NAME']; ?>';
      HP_DUMM = <?= HP_DUMM; ?>;
      BATT_DUMM = <?= BATT_DUMM; ?>;
      ACTIVATION_FEE_PORT = <?= ACTIVATION_FEE_PORT; ?>;
      CURRENT_PHONE_ID_WITH_SERVICE = <?= CURRENT_PHONE_ID_WITH_SERVICE; ?>;
      EZ_CONTACT_SETUP_ID = <?= EZ_CONTACT_SETUP_ID; ?>;
    </script>
    <script src='<?= $mainSitePath ?>js/plans.js' type='text/javascript'></script>
<!-- plans_script() - END -->
<?php
}

// Show lightbox version of plans selector
function plans_lightbox() {
  global $plans, $mainSitePath, $coverageChecker, $lightbox, $request_type;

  if ($coverageChecker || pathinfo($_SERVER['PHP_SELF'], PATHINFO_DIRNAME) == '/senior-cell-phone-plans') {
?>
    <div id='coverageChecker' title='' style='display:none;'>
      <style>
        .ui-dialog-titlebar {
          z-index: 5;
        }
        .framed {
          z-index: 0;
          position: absolute;
          width: 960px;
          height: 890px;
          top: -90px;
          left: -10px;
        }
        .coverage_gradient {
          z-index: 2;
          position: absolute;
          top: 0px;
          left: 0px;
          width: 950px;
          height: 35px;
        }
        .coverage_logo {
          z-index: 2;
          position: absolute;
          top: 0px;
          right: 0px;
          padding: 40px 20px 0px 230px;
        }
        .coverage_logo img {
          height: 67px;
        }
      </style>
      <iframe class='framed' src='<?= HTTP ?>://www.att.com/maps/reseller-pay-as-you-go.html' frameborder='0' scrolling='no'></iframe>
      <div class='coverage_gradient'></div>
      <div class='coverage_logo'><img src='/images/menu/menu2013/snapfon-the-cellphone-for-seniors-logo.png' /></div>
    </div>
<?php } ?>
    <div id='imageviewer' style='display: none;'>
      <script>
        function imageViewer(img) {
          $('#imageviewer img').attr('src', img);
          $('#imageviewer').dialog('open');
          return true;
        }
      </script>
      <img />
    </div>
    <div id='watchvideo' style='display: none;'>
      <script>
        function watchVideo(v) {
          $('#watchvideo iframe').attr('src', '<?= HTTP ?>://www.youtube.com/embed/' + v + '?list=PLQkxMbzK1Jkl0RRVbb8Xw1fXlpCzn0Ivf&autoplay=1');
          $('#watchvideo').dialog('open');
          return true;
        }
        function stopVideo() {
          $('#watchvideo iframe').attr('src', '')
          return true;
        }
      </script>
      <div class='fake-close'>
        <a href='#' class='ui-dialog-titlebar-close ui-corner-all'><span class='ui-icon ui-icon-closethick'></span></a>
      </div>
      <iframe width='560' height='315' frameborder='0' allowfullscreen></iframe>
    </div>
    <div id='playsiren' style='display: none;'>
      <script>
        function playSiren() {
          $('#playsiren iframe').attr('src', '/catalog/product_detail_pages/sirenSample.html');
          $('#playsiren').dialog('open');
          return true;
        }
        function stopSiren() {
          $('#playsiren iframe').attr('src', '')
          return true;
        }
      </script>
      <div class='fake-close'>
        <a href='#' class='ui-dialog-titlebar-close ui-corner-all'><span class='ui-icon ui-icon-closethick'></span></a>
      </div>
      <div>
        <iframe scrolling='no' style='border: 0px; margin: none; padding: none; width: 200px; height: 200px;'></iframe>
      </div>
    </div>
    <div id='planpicker'<?= ($lightbox) ? 'class=\'lightbox\' ' : '' ; ?> style='<?= ($lightbox) ? 'display: none;' : 'margin: 0; padding: 0;'; ?>'>
      <div class='plan'>
        <div class='th'>
          <h3>Cellular Service Plans <span>(choose a new number OR transfer an existing number)</span><a name='planpicker' href='' onclick='return false;' style='font-size: 2px; color: transparent;'>.</a></h3>
        </div><div class='th button'>
<?php if ($lightbox == false) { ?>
          <a href='<?= $mainSitePath ?>shop/shopping_cart.php'><span class='blue button'>Check Out</span></a>
<?php } ?>
        </div>
      </div>
      <hr />
      <div class='plan'>
        <div class='th voice_plan'>Voice Plan</div>
        <div class='th minutes'>Minutes</div>
        <div class='th includes'>Includes</div>
        <div class='th price'>Price</div>
      </div>
      <hr />
<?php
if (STORES_ID != 10) {
  show_plan(PLAN_BF_ID);
  echo '<hr />';
  show_plan(PLAN_BU_ID);
}
?><div class='split'>Premium plans include <span style='color: red;'>sos</span><span style='color: black;'>Plus Mobile<sup>&trade;</sup></span> for added safety and peace of mind.</div><?php
show_plan(PLAN_PF_ID);
echo '<hr />';
show_plan(PLAN_PU_ID);
echo '<hr />';
?>
      <div class='plan'>
        <div class='th'>
          <h3>Note: You can only have one plan in your cart at a time.</h3>
        </div><div class='th button'>
<?php if ($lightbox == false) { ?>
          <a href='<?= $mainSitePath ?>shop/shopping_cart.php'><span class='blue button'>Check Out</span></a>
<?php } ?>
        </div>
      </div>
      <h2>Benefits that are unique to Snapf&#333;n</h2>
      <div id='plansOneCallMobile'>
        <div>
          <h3>SosPlus Mobile Monitoring Service</h3>
          <p>
            Our sosPlus Mobile Monitoring Service can be activated just by pressing the SOS button on the back of your ezTWO for 5 seconds.
            A trained and certified operator will answer your call on the first ring and greet you by name. Our professional operators have your medical
            history and emergency contact list and know who to dispatch in case of trouble. We will even remain on the line with you until help arrives.
            When no one else can be there for you 24 hours a day, 365 days a year, We are proud to be your lifeline.
          </p>
          <a href='/services/onecall_mobile.php'>click here for more information</a>
        </div>
      </div>
      <div id='plansHandsetProtection'>
        <div>
          <h3>ezProtection Handset Replacement</h3>
          <p>
            We know that accidents happen. That's why we have included a unique protection package with our service. We cover
            many forms of physical damage including water, and most things in between. There is no deductible, and we pay for shipping both ways.
            We want you to rely on your Snapf&#333;n, so we created a plan that makes it a snap. We insure that you are covered, with no additional out of
            pocket expenses or inconveniences, because accidents do happen.
          </p>
          <a href='/services/handset_protection.php' class='ezGreen'>click here for more information</a>
        </div>
      </div>
    </div>

    <div id='activationpicker' title=''  style='display: none; margin: 0; padding: 0; background-image: url(/catalog/images/wizards/plans/activationTypeBackground.jpg); background-repeat: no-repeat;'>
      <div id='activationpickertable'>
        <table width='100%'>
          <tr>
            <td class='ezGreen beefy'>Phone Number Setup</td>
          </tr>
          <tr>
            <td>Do you need to transfer an existing number?</td>
          </tr>
          <tr>
            <td>
              <input type='radio' name='activationTypeCtl' id='activationTypePort' value='<?= ACTIVATION_FEE_PORT ?>'> Yes
              (<input type='text' class='numeric' name='portAreaCode' id='portAreaCode' value='' size='4' maxlength='3' />)
              <input type='text' class='numeric' name='portExchange' id='portExchange' value='' size='4' maxlength='3' />
              <input type='text' class='numeric' name='portNumber' id='portNumber' value='' size='5' maxlength='4' /><br>
              <span class="ezGreen">Number to be transferred</span>
            </td>
          </tr>
          <tr>
            <td>
              <input type='radio' name='activationTypeCtl' id='activationTypeNew' value='<?= ACTIVATION_FEE_NEW ?>' checked /> No, I need a new phone number.
            </td>
          </tr>
          <tr>
            <td>
              <img height='75%' id='activationPickerContinueButton' onclick=''
                src='/catalog/images/refresh_2012/continue-button.png'
                onmouseover='this.src="/catalog/images/refresh_2012/continue-button_over.png"'
                onmouseout='this.src="/catalog/images/refresh_2012/continue-button.png"'
                onmousedown='this.src="/catalog/images/refresh_2012/continue-button_click.png"'
                onmouseup='this.src="/catalog/images/refresh_2012/continue-button_over.png"' />
            </td>
          </tr>
        </table>
      </div>
    </div>

    <div id='noIE7' title=''  style='display: none; margin: 0; padding: 0; background-image: url(/catalog/images/wizards/plans/activationTypeBackground.jpg); background-repeat: no-repeat;'>
      <div id='noIE7table' style='background-color: transparent !important;'>
        <table width='85%' style='margin-top:105px;'>
          <tr>
            <td colspan='2' class='ezGreen beefy biggerText'>Internet Explorer 8 or Later Required</td>
          </tr>
          <tr>
            <td colspan='2' class='bigText'>
            Sorry, but this site requires Internet Explorer 8 or Later. Please either upgrade your copy of IE to version 8 (or later), or switch to one of these supported browsers.<br><br>
            </td>
          </tr>
          <tr>
            <td class='bigText'><a href='<?= HTTP ?>://chrome.google.com/' target='chrome'>Chrome</a></td>
            <td class='bigText'><a href='<?= HTTP ?>://mozilla.org/' target='moz'>Firefox</a></td>
          </tr>
        </table>
      </div>
    </div>

    <div id='ezContactPicker' title='' style='display: none;'>
      <style>
          div#ezContactPicker .background {
            background-image: url(/catalog/images/wizards/ezcontact/add-ezcontact-wizard-lightbox-background.jpg );
          }
      </style>
      <div class='background'>
        <div class='contents'>
          <span id='ezContactYes' class='button'>Add to Cart</span>
          <span id='ezContactNo' class='button'>No thanks</span>

          <div id='ezContactPickertable2'>
            <iframe id='myezplayer' width='321' height='200' frameborder='0' allowfullscreen
              src='<?= HTTP ?>://www.youtube.com/embed/ASGbqVeAYDY'>
            </iframe>
            <!-- span id='ezPlayButton' class='button'
              onclick='myezplayer.playVideo();'
            >Play Video &#9654;</span -->
          </div>
        </div>
      </div>
    </div>

    <table id='checkoutPicker' style='display: none; background-image: url(/catalog/images/refresh_2012/add-to-cart-wizard-lightbox-background.jpg); ' width='900' cellpadding='0' cellspacing='0'>
      <tr height='94'>
        <td rowspan='2' width='45'></td>
        <td colspan='2' width='810'></td>
        <td rowspan='2' width='45'></td>
      </tr>
      <tr>
        <td>
          <img id='checkoutPickerCart' src='/catalog/images/refresh_2012/check-out-blue-button.png'
            alt='Checkout'
            onclick="document.location.href='/catalog/shopping_cart.php'"
            onmouseover="this.src='/catalog/images/refresh_2012/check-out-blue-button_over.png'"
            onmouseout="this.src='/catalog/images/refresh_2012/check-out-blue-button.png'"
            onmousedown="this.src='/catalog/images/refresh_2012/check-out-blue-button_click.png'"
            onmouseup="this.src='/catalog/images/refresh_2012/check-out-blue-button_over.png'" />
        </td>
        <td align='right'>
          <img id='checkoutPickerShop' src='/catalog/images/refresh_2012/add-accessories-button.png'
            alt='Add Accessories'
            onclick="document.location.href='/catalog/'"
            onmouseover="this.src='/catalog/images/refresh_2012/add-accessories-button_over.png'"
            onmouseout="this.src='/catalog/images/refresh_2012/add-accessories-button.png'"
            onmousedown="this.src='/catalog/images/refresh_2012/add-accessories-button_click.png'"
            onmouseup="this.src='/catalog/images/refresh_2012/add-accessories-button_over.png'" />
          <img id="checkoutPickerStay" src="/catalog/images/refresh_2012/return-to-shopping-button.png"
            alt="Return to Shopping"
            onclick="$('#checkoutPicker').dialog('close');"
            onmouseover="this.src='/catalog/images/refresh_2012/return-to-shopping-button_over.png'"
            onmouseout="this.src='/catalog/images/refresh_2012/return-to-shopping-button.png'"
            onmousedown="this.src='/catalog/images/refresh_2012/return-to-shopping-button_click.png'"
            onmouseup="this.src='/catalog/images/refresh_2012/return-to-shopping-button_over.png'" />
        </td>
      </tr>
    </table>
    <div id='flexInfo' title='' style='display: none; background-image: url(/plans/images/Flex-plan-details-lightbox-background.jpg); background-repeat: no-repeat;'>
      <center>
        <img src='/plans/images/Flex-Plan-Lightbox-image-3.png'  style='margin-top: 140px;' alt='Low cost Cell phone plans designed for seniors' title='Our Flex Plans'/>
      </center>
    </div>
<?php
}

// Show standalone plans page
function plans_page() {
  global $mainSitePath, $request_type;
?>
<!doctype html>
<html>
  <head>
    <title>Cell Phones with Plans Made for Seniors | (800) 937-1532 | Snapfon</title>
<?php
    include_once(DIR_FS_ROOT . 'includes/executable.php');
    include_once(DIR_FS_ROOT . 'includes/meta.php');
?>
    <meta name='description' content='Tailored to how the elderly use their mobile devices, ezTWO cell phones are included with Snapfon cell phone plans for seniors, each with varying flexibility.'>
	<meta name="keywords" content="cell phone plans for seniors">
<?php
    include_once(DIR_FS_ROOT . 'includes/links.php');
    include_once(DIR_FS_ROOT . 'catalog/includes/product_id_values.php');
?>
    <script type='text/javascript' src='<?= $mainSitePath ?>fancybox/jquery.fancybox-1.3.1.pack.js'></script>
    <link rel='stylesheet' href='<?= $mainSitePath ?>fancybox/jquery.fancybox-1.3.1.css' type='text/css' media='screen' />
    <script type='text/javascript' src='<?= $mainSitePath ?>js/swfobject.js'></script>
<?php plans_head(); ?>
<?php plans_script(); ?>
    <script type='text/javascript'>
      var fb_param = {};
      fb_param.pixel_id = '6006195267217';
      fb_param.value = '0.00';
      (function(){
        var fpw = document.createElement('script');
        fpw.async = true;
        fpw.src = (location.protocol=='http:'?'http':'https')+'://connect.facebook.net/en_US/fp.js';
        var ref = document.getElementsByTagName('script')[0];
        ref.parentNode.insertBefore(fpw, ref);
      })();
    </script>
    <noscript><img height='1' width='1' alt='' style='display:none' src='https://www.facebook.com/offsite_event.php?id=6006195267217&amp;value=0' /></noscript>
  </head>
  <body>
    <img src='https://secure.adnxs.com/seg?add=799496&t=2' width='1' height='1' /><!-- retargeter -->
    <div id='pageBody'>
<?php include_once(DIR_FS_ROOT . 'includes/pageHeader.php'); ?>
      <div id='plans_page'>
        <div id='plans_header'>
          <div class='left'>
            <h1>Affordable Nationwide Talk &amp; Text Plans</h1>
            <p>
              We know your first concern is quality coverage.
              Snapf&#333;n&reg; handsets operate on the United States' largest GSM network, powered by PureTalk USA.
              Our senior cell phone plans have no additional taxes* or monthly fees,
              and include our exclusive ezProtection Handset Replacement Program,
              which insures that your phone is protected from damage for as long as you have our service.
            </p>
          </div>
          <div class='right coverageChecker'>
            <img src='<?= $mainSitePath; ?>images/coveragemap_icon.png' /><br />
            <a>click to check coverage</a>
          </a>
        </div>
      </div>
<?php plans_lightbox(); ?>
      
      </div>
    </div>
<?php include_once(DIR_FS_ROOT . 'includes/pageFooter.php'); ?>
  </body>
</html>
<?php
}
?>
