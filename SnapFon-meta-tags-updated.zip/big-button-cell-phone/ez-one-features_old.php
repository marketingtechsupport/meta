<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<? define( 'SUBDIR', 'about-snapfon-products'); ?>
		<? include_once( '../includes/executable.php'); ?>
		<? //include_once( $mainSitePath . 'includes/meta.php'); ?>
		<meta name="description" content="Big button cell phones that are easy to use and easy to see.  The Snapfon ezONE is the best senior phone on the market.">
		<meta name="keywords" content="Big Button Cell Phones, Senior Phone">
		<? include_once( $mainSitePath . 'includes/links.php'); ?>
		
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.4.2.min.js"></script>
		<script type="text/javascript" src="./fancybox/jquery.fancybox-1.3.1.pack.js"></script>
		<script type="text/javascript" src="./view360/swfobject21.js"></script>
		<link rel="stylesheet" href="./fancybox/jquery.fancybox-1.3.1.css" type="text/css" media="screen" />

				
		<title>Big Button Cell Phones | Snapfon ezONE | Features</title>

	</head>
	<body>
	<div id='pageBody'>
		<? include_once( $mainSitePath . 'includes/pageHeader.php'); ?>
		<table cellpadding="0" cellspacing="0" border="0">
			<tr>
				<td rowspan="1" valign="top">
					<? include_once( $mainSitePath .  'includes/leftMenu.php'); ?>
				</td>
				<td valign="top">
					<div id='attractBlock'>
						<table>
							<tr>
								<td valign="top">
									<div style="padding-left:10px;padding-right:10px;font-size:large;" class="grayText">
										<h1><span class='snapName'>Snapf&#333;n&reg;</span> <span class="accentColor">ez</span> <span class='snapName'>ONE</span><br>
										The Big Button Cell Phone</h1>

										There is no other big button cell phone that is as simple to use as the ezONE from 
										<span class='snapName'>Snapf&#333;n&reg;</span> <span class="">ez</span> <span class='snapName'>ONE</span>.
										<br><br>
										Our phone has:
										<ol class='accentColorList'>
											<li><span>Big keys and large print.</span></li>
											<li><span>Easy to read screen</span></li>
											<li><span>Enhanced volume</span></li>
											<li><span>Speaker Phone</span></li>
											<li><span>SOS Button</span></li>
											<li><span>Speaking Keypad</span></li>
											<li><span>Extended battery life</span></li>
											<li><span>Bright LED Flashlight</span></li>
											<li><span>FM Radio</span></li>
											<li><span>GSM World Phone</span></li>										
										</ol>
										<a href="../catalog/index.php?op=addAPhone">
										<img style="float:left; margin-top:0px;" onmouseup="this.src='../catalog/images/AddToCartButton.png'" onmousedown="this.src='../catalog/images/AddToCartButton_click.png'" onmouseout="this.src='../catalog/images/AddToCartButton.png'" onmouseover="this.src='../catalog/images/AddToCartButton_over.png'" src="../catalog/images/AddToCartButton.png">
										</a>
									</div>
								</td>
								<td>
									<img src="../images/phone/snapfon-ez-one-chart.jpg" alt="snapfon-ez-one-chart" width="288" height="480" vspace="5" align="right" />
								</td>
							</tr>
						</table>
					</div>
				</td>
				<td valign="top">
					<? include_once(  $mainSitePath . 'includes/sideTrust.php'); ?>
					<!-- optional right-side element goes here -->
					<a href="../catalog/index.php"><img src="../images/cornerimages/accessories-corner.jpg" alt="accessories-corner" width="101" height="170" /></a>
				</td>
			</tr>
			<!-- The below varies from page to page -->
			<tr>
				<td colspan="3">
					<div id='featureSounds'>
						<div id='talkieSample'>
							<a href='../files/sounds/snapfon_speaking_keypad_sample.mp3' target="playsound">
							<img style="float:left; margin-top:0px;" onmouseup="this.src='../images/phone/play-sample.png'" onmousedown="this.src='../images/phone/play-sample-click.png'" onmouseout="this.src='../images/phone/play-sample.png'" onmouseover="this.src='../images/phone/play-sample-over.png'" src="../images/phone/play-sample.png">
							</a>
						</div>
						<div id='sosInfo' class="grayText">
							<b>SOS Button<br>Emergency Alert Feature</b>
							<ul class='accentColorList'>
								<li><span><b>Sounds an alarm</b><br>
								<i>(128 db at speaker)</i></span></li>
								<li><span><b>calls up to 4 programmable numbers</b><br>
								<i>(911 recommended first)</i></span></li>
								<li><span><b>get help in an emergency</b></span></li>							
							</ul>
							<a href='../files/sounds/snapfon_siren_sample.mp3' target="playsound">
							<img style="float:left; margin-top:0px;" onmouseup="this.src='../images/phone/play-sample.png'" onmousedown="this.src='../images/phone/play-sample-click.png'" onmouseout="this.src='../images/phone/play-sample.png'" onmouseover="this.src='../images/phone/play-sample-over.png'" src="../images/phone/play-sample.png">
							</a>
						</div>
					</div>
				</td>
			</tr>
			<tr>
				<td colspan="3" align="center">
					<table cellpadding="5">
						<tr>
							<td>
								<img src="../images/phone/led-flashlight-block.jpg" alt="led-flashlight-block" width="479" height="183" />
							</td>
							<td>
								<img src="../images/phone/fm-radio-block.png" alt="fm-radio-block" width="480" height="182" />
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	
		<? include_once( $mainSitePath . 'includes/pageFooter.php'); ?>
	</div>
	<pre>
	<!-- <?= __FILE__ ?> -->
	<? // print_r($browser_info); ?>
	</pre>
	</body>
</html>
