<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<? define( 'SUBDIR', 'about-snapfon-products'); ?>
		<? include_once( '../includes/executable.php'); ?>
		<? //include_once( $mainSitePath . 'includes/meta.php'); ?>
		<meta name="description" content="The Snapfon ezONE has some fantastic safety features, as well as being one of the easiest to use cell phones on the market today.">
		<meta name="keywords" content="Snapfon ezONE Mobile Phone for Seniors is easy to see and easy to use.">
		<? include_once( $mainSitePath . 'includes/links.php'); ?>
		
		<title>Snapfon ezONE - Providing Quality Mobile Phones for Seniors</title>
		<style type='text/css'>
			/* Styles specific to this page */
		</style>
	</head>
	<body>
	<div id='pageBody'>
		<? include_once( $mainSitePath . 'includes/pageHeader.php'); ?>
		<!--div class='brownDivider'>&nbsp;</div-->
		<?
		if ($browser_info['platform'] == 'linux') {
			if ($browser_info['name'] == 'chrome') {
				$h = 630;
				}
			else {
				$h = 670;
				}
			}
		else if ($browser_info['platform'] == 'windows') {
			if ($browser_info['name'] == 'chrome') {
				$h = 600;
				}
			else {
				$h = 600;
				}
			}
		else {
			$h = 600;
			}
		?>
		<div id='mainBlock' class="grayBack" style="width:100%; height:<?= $h ?>px;">
			<div class="grayBack grayText" style='margin-left:19px; float:left; width:670px;text-align:justify;'>
				<h1 style='margin-top:16px;'>About Snapfon: Providing Quality Mobile Phones for Seniors</h1>
				<span class='snapName'>Snapf&#333;n<sup>&reg;</sup></span> is a part of <span class='snapName'>VisiKey&reg;, LLC.</span>, a privately held company based in Chattanooga, Tennessee. 
				<span class='snapName'>VisiKey&reg;</span> started manufacturing and selling enhanced visibility computer keyboards 
				in 2003. <span class='snapName'>The VisiKey&reg;</span> keyboard is a multimedia style keyboard with one huge advantage: larger printing on the keys. Our print is actually 430% larger than conventional keyboards when 
				measured with the Snellen Visual Accuity Scale. Large print keyboards have been around for quite some time, unfortunately they look very dated, and lack functions relevant to todays users. 
				Since there were few options with respect to regular keyboards with improved visibility, we felt the market was ripe for keyboards that offered modern layouts but were far easier to see. 
				<span class='snapName'>VisiKey&reg;</span> was the first to add multimedia functions to keyboards with large print, thus making the keyboards more desirable to both the general public, and the visually impaired.
				<br><br>
				This concept is the driving force behind <span class='snapName'>Snapf&#333;n</span>. Cellular telephones are getting more and more complex. With the introduction of the iPhone, manufacturers are under more pressure to create 
				smaller, faster, and more featured smartphones. <span class='snapName'>Snapf&#333;n</span> is at the opposite end of the spectrum. Our goal was to produce the easiest to see, and easiest to use phone on the market. We succeeded!
				Best of all, it can be purchased through the mainstream cellular markets and is not limited to the visually impaired. The biggest benefit of this approach is it means we will sell more phones, 
				which allows us to be more efficient, and more competitive. That translates to a low price for every type of consumer, instead of the high price of a specialty product.
				<br><br>
				The physical location of <span class='snapName'>Snapf&#333;n's</span> office is:
				<br><br>
				<span class='snapName'>
				1222 Tremont Street<br>
				Suite 100<br>
				Chattanooga, TN 37405
				</span>
				<br><br>
				Residents of the greater Chattanooga and North Georgia areas, may take advantage of our retail center Monday through Friday from 9:00 AM to 5:00 PM.
				<br><br>
				We ship to all 50 states and throughout the world using either standard shipping, overnight, or expedited delivery upon request.
				<br><br>
				If you need additional information about <span class='snapName'>Snapf&#333;n</span>, our outstanding customer service representatives are happy to assist you. Just give us a call any time!
			</div>
			<div style="float:right; width:243px; margin-right:20px;margin-top:80px; border:none;" class="grayBack">
				<img align="bottom" src="<?= $mainSitePath ?>images/fullFrontalPhone.png" alt="The Snapfon ezONE Mobile Phone for Seniors" title="Snapfon's ezONE - Easy to See, Easy to Read" width="243" height="482" />
			</div>
		</div>
		<div class="grayText" 
		style="width:100%; height:400px;">
			<div style="width:495px;float:left; border:none; margin-left:40px; margin-top:40px;">
			<img src="../images/keyboardBig.jpg" alt="Visikey Enhanced Visibility Keyboard" title="Computer Keyboard with 430% larger text reduces eye strain" width="495" height="347" />
			</div>
			<div style="width:380px; margin-right:20px; margin-top:100px; float:right; border:none;">
			<img src="../images/visikeyLogo.jpg" alt="Visikey, LLC: Manufacturer of Computer Keyboards for Low-Vision Clients since 2003" title="Visikey, LLC" width="239" height="68" />
			<br><br>
			Be sure to visit our parent company, <a href='http://www.visikey.net' target='visikey'>Visikey</a>. Visikey manufactures large print USB computer keyboards for visually-impaired users. 
			</div>
		</div>
		<? include_once( $mainSitePath . 'includes/pageFooter.php'); ?>
	</div>
	<pre>
	<? //print_r($browser_info); ?>
	</pre>
	</body>
</html>
