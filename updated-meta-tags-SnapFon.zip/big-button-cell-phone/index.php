<? //ini_set('display_errors','1'); ?>
<?
	chdir("../catalog/");
	require('includes/application_top.php'); 
?>
<!doctype html>
<html>
	<head>
		<? // define( 'SUBDIR', 'about-snapfon-products'); ?>
    <?php include_once(DIR_FS_ROOT . '/includes/meta.php'); ?>
    <?php include_once(DIR_FS_ROOT . '/includes/executable.php'); ?>
        <meta name="description" content="Featuring big buttons, ezTWO cell phones for the elderly are made for ease of use. These cell phones for elderly people also have built-in SOS for added safety.">
        <meta name="keywords" content="cell phones for the elderly, cell phones for elderly people">
        <?
		
			$category_id = SHOW_ACCESSORIES_ID;
			if (isset( $showAcc) && ($showAcc == "1")) {
				$category_id = SHOW_ACCESSORIES_ID;
			}

			if (!isset($category_id) || ($category_id == "") || ($category_id == 0)) {
				if ($category_id != SHOW_ACCESSORIES_ID) {
					$category_id = SHOW_ALL_ID;
				}
			}
//if (isset( $_GET['phonesToExclude'])) {
//	$_SESSION['phonesToExclude'] = $_GET['phonesToExclude'];
//	}

// the following cPath references come from application_top.php
  $category_depth = 'top';
  if (isset($cPath) && tep_not_null($cPath)) {
    $categories_products_query = tep_db_query("select count(*) as total from " . TABLE_PRODUCTS_TO_CATEGORIES . " where categories_id = '" . (int)$current_category_id . "'");
    $cateqories_products = tep_db_fetch_array($categories_products_query);
    if ($cateqories_products['total'] > 0) {
      $category_depth = 'products'; // display products
    } else {
      $category_parent_query = tep_db_query("select count(*) as total from " . TABLE_CATEGORIES . " where parent_id = '" . (int)$current_category_id . "'");
      $category_parent = tep_db_fetch_array($category_parent_query);
      if ($category_parent['total'] > 0) {
        $category_depth = 'nested'; // navigate through the categories
      } else {
        $category_depth = 'products'; // category has no products, but display the 'no products' message
      }
    }
  }

		
		?>
			<?  //include_once( "../catalog/includes/configure.php");
			$qCon = mysql_connect( DB_SERVER, DB_SERVER_USERNAME, DB_SERVER_PASSWORD);
			mysql_select_db( DB_DATABASE);
		?>
		<?php include_once( DIR_FS_ROOT . 'includes/links.php'); ?>
		<link rel="stylesheet" type="text/css" href="/catalog/snapcatalog.css">

		<? // Crank up jquery ?>
		<? // oops! Actually, dojo starts jquery. So the next line isn't needed really ?>
		<!-- script type="text/javascript" src="http://code.jquery.com/jquery-1.4.2.min.js"></script -->
		
		<? // some of the following includes can come out, on a page by page basis ?>
		<script type="text/javascript" src="<?= $mainSitePath ?>fancybox/jquery.fancybox-1.3.1.pack.js"></script>
		<link rel="stylesheet" href="<?= $mainSitePath ?>fancybox/jquery.fancybox-1.3.1.css" type="text/css" media="screen" />
		<script type="text/javascript" src="<?= $mainSitePath ?>js/swfobject.js"></script>

		<!-- <script src='../includes/flot/jquery.flot.js' type="text/javascript"></script> -->

		<title>Easy to Use Cell Phones for Seniors | Call (800) 937-1532 | Snapfon</title>
		
		<script>
		
//product browser functions
		function switchMain(imgfile)
		{
			var imgpath = '/images/eztwofeatures/';
			document.getElementById('imgMain').src = imgpath+imgfile;
		}
		
		function toggleSide(elImg, imgfile)
		{
			var imgpath = '/images/eztwofeatures/';
			elImg.src = imgpath+imgfile;
		}
		
		</script>
	
    <script type="text/javascript">
        var fb_param = {};
        fb_param.pixel_id = '6006195267217';
        fb_param.value = '0.00';
        (function(){
            var fpw = document.createElement('script');
            fpw.async = true;
            fpw.src = (location.protocol=='http:'?'http':'https')+'://connect.facebook.net/en_US/fp.js';
            var ref = document.getElementsByTagName('script')[0];
            ref.parentNode.insertBefore(fpw, ref);
        })();
    </script>
    <noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/offsite_event.php?id=6006195267217&amp;value=0" /></noscript>
    <style type="text/css">
		.playa { padding-top: 100px;}
    </style>
	</head>
	<body>
<img src="https://secure.adnxs.com/seg?add=799496&t=2" width="1" height="1" />
	<div id='pageBody'>
		<?php include_once( DIR_FS_ROOT . 'includes/pageHeader.php'); ?>
		<table cellpadding='0' cellspacing='0' width='100%'>
			<tr>
				<td id='pageBodyCell' class='phone_page' align='center'>
					
					<!-- START Snapfon ezTWO TABLE -->
              <div class='order_phone'>
                <!-- Phone Details pic browser -->
                <img id='imgMain' src='/images/eztwofeatures/eztwo-front2.png' alt='main phone view' />
                <div id='phone_rollovers'>
                  <!-- Detailed Side rollovers -->
                  <?php $imagefile = 'eztwo-rear'; ?>
                  <img src='/images/eztwofeatures/<?= $imagefile ?>-sm.png' onmouseover="$('#imgMain').attr('src', '/images/eztwofeatures/<?= $imagefile ?>.png');" />
                  <?php $imagefile = 'eztwo-top-bottom'; ?>
                  <img src='/images/eztwofeatures/<?= $imagefile ?>-sm.png' onmouseover="$('#imgMain').attr('src', '/images/eztwofeatures/<?= $imagefile ?>.png');" />
                  <?php $imagefile = 'eztwo-sides'; ?>
                  <img src='/images/eztwofeatures/<?= $imagefile ?>-sm.png' onmouseover="$('#imgMain').attr('src', '/images/eztwofeatures/<?= $imagefile ?>.png');" />
                  <?php $imagefile = 'eztwo-front2'; ?>
                  <img src='/images/eztwofeatures/<?= $imagefile ?>-sm.png' onmouseover="$('#imgMain').attr('src', '/images/eztwofeatures/<?= $imagefile ?>.png');" />
                </div><br />
                <br />
                <a onclick='imageViewer("/images/eztwofeatures/eztwo-details.png");'>click here for detailed features</a>
              </div>
              <div class='order_phone'>
                <span class="bigOlText">ezTWO</span><br />
                  <h1>
                  Big numbers and buttons with built in SOS<br />
                  make this phone the best choice for seniors.
                  </h1>
                <div>
                  <div class='phone_plan'>
                    <span class="ezGreen bigOlText">$<?= PRICE_WITH_PLAN ?></span><br />
<? /*
                    with any service plan<br /> starting at<br />
                    only <?= money_format('$%i', BASIC_FLEX_PLAN_PRICE); ?> a month<br />
                    <br /><br />
*/ ?>
                    with any Basic Plan<br />
                      <!-- or<br />
                              <strong class="ezGreen">FREE</strong> with any Premium Plan<br /><br /><br /> -->
                    <span class="ezGreen">*one-time $<?= ACTIVATION_FEE_AMOUNT ?> activation fee required</span><br /><br />
<?php require_once(DIR_FS_ROOT . 'senior-cell-phone-plans/plans.php'); ?>
                    <span id='addPhoneWithService' class='button' onClick='doAddOneMore( 1, <?= CURRENT_PHONE_ID_WITH_SERVICE ?>)'>Add to Cart</span>
                    <br />
                    Quantity: <span class='smallText' id="qty_pws"><?= $cart->get_quantity( CURRENT_PHONE_ID_WITH_SERVICE) ?></span><br />
                    <span id='limitPhonesWithService'>Limit 1 per order.<br /><br /></span>
                  </div>

                  <hr class='vertical_bar' style='height: 240px;' />

                  <div class='phone_plan'>
                    <span class="ezGreen bigOlText">$<?= PRICE_WITHOUT_PLAN ?></span><br />
                    unlocked ezTWO for use<br />
                    with service of your<br />
                    choice<br />
                    <br />
                    <span class="ezGreen">
                      for use with unlocked<br />
                      2G GSM service<br />
                    </span><br />
                    <span id='addPhoneWithoutService' class='button' onClick='doAddOnePhoneWithoutPlan(<?= CURRENT_PHONE_ID ?>)'>Add to Cart</span>
                    <br clear='all' />
                    Quantity: <span class='smallText' id="qty_pwos"><?= $cart->get_quantity( CURRENT_PHONE_ID) ?></span><br />
                    <span id='limitPhonesWithService' class='' style="font-size:12pt;"><br /></span>
                  </div>
                </div>
                <div class='notifiers'>
                  <span class="bigText ezGreen"> 
                  FREE Accessory<br />
                  Orders process in 2-3 business days.<br />
                  </span>
<?php /*
                  <span class="biggishText ezGreen">Get it faster by choosing Rush Processing during checkout!</span><br />
*/ ?>
                </div>
							</div>

							<hr />
              <div id="div_tabcontent_details" class="tabContentPane">
              
                <table width='100%'>
                  <tr>
                    <td valign="top">
                    <div id='easy_to_use'>
                      <h2>Easy-to-Use features:</h2>
                      <ul class='nobr'>
                        <li><span>Keypad lock slide switch - <a onclick="watchVideo('ujrrrMohpts')">Watch Video</a></span></li>
                        <li class='exclusive'><span>Speaking keypad - <a onclick="watchVideo('4k9urIR8lAA');">Watch Video</a></span></li>
                        <li><span>Enhanced volume &amp; Speaker phone - <a onclick="watchVideo('ZG7bthdMzLU');">Watch Video</a></span></li>
                        <li><span>High power LED flashlight - <a onclick="watchVideo('YVPuflICkFs');">Watch Video</a></span></li>
                        <li class='exclusive'><span>Low Battery Warning System - <a onclick="watchVideo('S2o28gwxe4I');">Watch Video</a></span></li>
                        <li><span>8 Speed Dial Keys - <a onclick="watchVideo('SKQTeboE2-4');">Watch Video</a></span></li>
                        <li><span>Simplified menus - <a onclick="watchVideo('bWBHJZ3kRR0');">Watch Video</a></span></li>
                        <li><span>Hearing Aid Compatible (M3/T3)</span></li>
                        <li><span>4 Alarm Modes - <a onclick="watchVideo('JfB0UNjy9S8');">Watch Video</a></span></li>
                        <li><span>Instructional Videos available - <a href='/blog/eztwo_videos/'>Watch Videos</a></span></li>
                      </ul>
                      <div id='exclusive'>
                        <img src='/images/snapfon-exclusive-logo-med.png' alt='snap icon' />
                        <span>Snapf&#333;n&reg; EXCLUSIVE features!</span>
                      </div>
                    </div>
                    </td>
                    <td valign='top'>
                      <div id='sos_emergency'>
                        <h2>SOS Emergency Alert</h2>
                        <ul>
                          <li>Press and hold for 3 to 5 seconds to alert up to 5 responders by voice and text message</li>
                          <li>Loud 120 db siren can alert those close-by to emergency (can be switched off in menu)</li>
                          <li>Automatically switches to speaker phone mode for emergency calls</li>
                        </ul>
                      </div>
                      <div>
                        <h2>24/7 Monitoring Service</h2>
                        <ul>
                          <li>
                            Included with any Premium plan, one button press connects you to our 24/7 Mobile Monitoring Service.
                            <img id='onecall' src='/images/sosPlus-logo.png' alt='oneCall Mobile Monitoring Service' />
                          </li>
                        </ul>
                      </div>
                    </td>
                    <td align='center'>
                      <div>
                        <img id='sos_phone' src='/images/eztwofeatures/eztwo-rear.png' alt='SOS emergency alert feature' border='0' />
                        <br />
                        <span class='button' onClick='playSiren()'>
                          Play Siren &#9654;
                        </span>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td colspan='3'>
                      <hr />
                      <div id='whats_in_box'>
                        <div class='list'>
                            <!-- <img src='/images/ezonefeatures/snapfon-box.png' alt='senior cellphone box' border='0'> -->
                          <h2>What's In The Box</h2>
                          <div>
                            <ul>
                              <li>One Snapf&#333;n&reg; ezTWO cell phone</li>
                              <li>One wall charger</li>
                              <li>One battery</li>
                              <li>One Snapf&#333;n&reg; ezTWO user guide</li>
                            </ul>
                          </div>
                        </div>
                        <img src='/images/eztwofeatures/eztwo-senior-cellphone-thumb.png' />
                        <img src='/images/eztwofeatures/eztwo-charger-thumb.png' />
                        <img src='/images/eztwofeatures/eztwo-battery-thumb.png' />
                        <img src='/images/eztwofeatures/eztwo-manual-thumb.png' />
                        <div>
                          Detailed specifications can be found <a href='/support/eztwo/tech_specs.php'>HERE.</a>
                        </div>
                      </div>
                    </td>
                  </tr>
                </table>
              </div> <!-- div_tabcontent_details -->
					<!-- END Snapfon ezONE TABLE -->
					
				</td>
			</tr>
		</table>
		
		<?php include_once( DIR_FS_ROOT . 'includes/pageFooter.php'); ?>
	</div>
	
</body>
</html>
