<? 
chdir("../catalog");
require("includes/application_top.php"); 
?>
<!doctype html>
<html>
	<head>
		<? define( 'SUBDIR', 'about-snapfon-products'); ?>
		<?php include_once(DIR_FS_ROOT . '/includes/meta.php'); ?>
		<?php include_once(DIR_FS_ROOT . '/includes/executable.php'); ?>
		<meta name="description" content="Looking for reliable cell phone plans for senior citizens? Snapfon�s senior citizen cell phone plans include OneCall Mobile for users with an active lifestyle.">
		<meta name="keywords" content="cell phone plans for senior citizens, senior citizen cell phone plans">
		<? include_once(DIR_FS_ROOT . '/includes/links.php'); ?>
		<? // but these should satay in for the pages that need ajax or dojo ?>
		<link rel="stylesheet" type="text/css" href="<?= HTTP ?>://ajax.googleapis.com/ajax/libs/dojo/1.5/dojo/resources/dojo.css" />
		<link rel="stylesheet" type="text/css" href="<?= HTTP ?>://ajax.googleapis.com/ajax/libs/dojo/1.5/dijit/themes/claro/claro.css" />
		<link rel="stylesheet" href="<?= $mainSitePath ?>styles/seniortechllc_slideshow.css" type="text/css" media="screen" />
		<script src='<?= $mainSitePath ?>js/dojo.1.5.2/dojo/dojo.js' type='text/javascript'></script>

		<title>OneCall Mobile Monitoring Services | Senior Cell Phone Plans | Snapfon</title>
		<style>
			.hero {
				margin: 0px;
				margin-bottom: 15px;
			}
			.hero .agent {
				display: inline-block;
				width: 150px;
				margin-top: 00px;
				vertical-align: top;
				text-align: center;
				color: #367C2B;
			}
			.hero .testimonial {
				display: inline-block;
				width: 795px;
				margin-left: 15px;
			}

			.hero td {
				vertical-align: top;
			}
			.hero h2 {
				margin: 0px;
				font-size: 1em;
			}
		</style>

	 <noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/offsite_event.php?id=6006195267217&amp;value=0" /></noscript>
	</head>
	<body>

		<div id='pageBody'>
			<? include_once(DIR_FS_ROOT . '/includes/pageHeader.php'); ?>
			<div id='slides' class='slideShow' style='width: 975px; height: 238px'>
				<div class='selectors'></div>
			</div>
			<table cellpadding="0" cellspacing="0">
				<tr>
					<td id='pageBodyCell'>

						<!-- ONE CALL TABLE START -->
						<table cellspacing="0" cellpadding="0">
							<tr>
								<td valign="top">
									<table style="margin-top:0px;">
										<tr>
											<td valign="top"><img src="/images/onecall/sos-plus-block.jpg" alt="sosPlus mobile personal emergency response system now available"></td>
											<td valign="top"><img src="/images/onecall/relaible-nationwide-coverage.jpg" alt="sosPlus mobile with nationwide coverage" onclick="checkCoverage();"></td>
										</tr>
										<tr>
											<td colspan="2">
												<h1>Why Choose sosPlus Mobile Monitoring?</h1>
												<div class="normalBigText" style="margin-right:25px;">
                                                    SosPlus Mobile Monitoring provides security and peace of mind for people who want to maintain an active lifestyle.
													When you choose Snapf&#333n's sosPlus Mobile emergency monitoring service, your SOS button will be connected
													When you choose Snapf&#333n's sosPlus Mobile emergency monitoring service, your SOS button will be connected
													24/7 to our friendly, highly skilled and trained sosPlus Mobile Response Agents via the built in speakerphone,
													this instant response system ensures that your emergency call never goes unanswered, no matter what the situation
													may be, 24 hours a day, 7 days a week, all at the touch of a button.<br> <br>Our response agents are able to assist
													in dispatching 9-1-1 emergency services, can conference in family and friends, and will stay on the line with
													you until your situation is resolved. Having a medical emergency? Lost? Feel threatened? Trip and fall accident?
                                                    sosPlus will be there when you need help most!<br><br> Now, you can have simplicity and security in one discrete device!
												</div>
											</td>
										</tr>
									</table>
								</td>
								<td valign="top">
									<!-- <div style="position:relative;left:0px;top:0px;background-color:transparent;">-->
									<img src="/images/onecall/eztwo-sos-plus-mobile-large-banner.jpg" alt="Mobile Protection, Security and peace of mind to live life to the fullest" style="margin-top:0px;">
									<img src="/images/onecall/ul-certified-monitoring-center.png" alt="UL certified monitoring center - us based customer support" style="margin-top:0px;">
									<div style="position:relative;left:25px;top:-158px;width:152px;height:38px;background-color:transparent;margin:0px;">
										<a href="/plans">
										<img src='/images/onecall/see-plans-button-up.png' border="0"
											onclick='' 
											onmouseover='this.src="/images/onecall/see-plans-button-over.png"' 
											onmouseout='this.src="/images/onecall/see-plans-button-up.png"' 
											onmousedown='this.src="/images/onecall/see-plans-button-down.png"' 
											onmouseup='this.src="/images/onecall/see-plans-button-up.png"' />
										</a>
									</div>
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<hr />
									<table width="975" border="0">
										<tr>
											<td colspan="2">
												<h1>Top 10 reasons to choose sosPlus!</h1>
											</td>
										</tr>
<!-- Hero template
										<tr>
												<td>
												<div class='hero'>
														<div class='agent'>
																<img>
														</div>
														<div class='normalBigText'>
																<h2></h2>
																<span class='ezGreen normalText'>
																</span><br/>
														</div>
												</div>
										</td>
										</tr>
-->
										<tr>
											<td>
												<div class='hero'>
													<div class='agent'>
														<img src="/images/onecall/Nathan-Keller.png" alt="sosPlus Response Agent :Nathan K."><br />
														Response Agent:<br />
														Nathan K.
													</div>
													<div class='testimonial normalBigText'>
														<h2>SOSPLUS SAVES STROKE VICTIM - Sep 17 2013</h2>
														<span class='ezGreen normalText'>MIRA LOMA,CA</span><br />
														A stroke happens about every 40 seconds. Each year, according to WebMD, about 795,000 Americans have a stroke.
														<br><br>
														On September 11th, 2013 at around 3pm, Linda pressed her button. "I...can't...talk...I don't know...what's happening to me," Linda faintly told sosPlus team member Nathan K.
														Nathan immediately dispatched the paramedics to Linda's home.
														<br><br>
														Within minutes, paramedics arrived on scene to assess Linda's condition. They immediately rushed her to the hospital.
														Later that same week, Linda herself called in to thank sosPlus for getting her the help that she needed. By getting EMS there so quickly, the doctors were able to prevent
														any major permanent damage. Linda later told sosPlus the following: "I wanted to personally thank you for saving my life. I was unable to talk and you sent help for me.
														You waited there with me and gave me hope that help was soon arriving. I am so thankful for what you did for me in my time of need."
														<br><br>
														We thank sosPlus team member Nathan K for his dedicated and caring service to Linda, giving her the added confidence that help is a button push away.
													</div>
												</div>
												<div class='hero'>
													<div class='agent'>
														<img src="/images/onecall/Alexander-Millar.png" alt="sosPlus Response Agent :Alexander M."><br />
														Response Agent:<br />
														Alexander M.
													</div>
													<div class='testimonial normalBigText'>
														<h2>WOMAN SUFFERS MINI STROKE - AUG 30 2013</h2>
														<span class='ezGreen normalText'>CLARKS SUMMIT, PA</span><br />
														On August 8th, 2013, Leona was cleaning up after dinner. While attempting to wash some dishes, Leona struggled more and more with each dish she cleaned. She realized something was wrong and pressed her button.
														<br><br>
                                                        sosPlus team member Alexander, answered her call and sent help to her home.
														<br><br>
														Upon arrival EMS assessed her symptoms as a stroke, and rushed her to the hospital. Leona's daughter said the doctors were able to treat the symptoms and prevent further damage.
														<br><br>
														Leona later told AG she is back at home and grateful that her medical system worked so well. "It worked, y'all couldn't
														prevent what happened to me, but you worked to get help to me fast," Leona commented.
													</div>
												</div>
												<div class='hero'>
													<div class='agent'>
														<img src="/images/onecall/Amy-Pittman.png" alt="sosPlus Response Agent :Alexander M."><br />
														Response Agent:<br />
														Amy P.
													</div>
													<div class='testimonial normalBigText'>
														<h2>UNABLE TO FIND OXYGEN TUBE - AUG 30 2013</h2>
														<span class='ezGreen normalText'>OGDEN, UT</span><br />
														Clarence receives oxygen 24/7. He relies on his machine day in and day out to help him get the oxygen he needs.
														On August 7th, around 4am, Clarence's nasal tube came out. Waking up, Clarence was confused and disoriented
														to what was going on around him. He was under the impression someone was trying to break into his house. Shirley,
														Clarence's wife, didn't realize anything was wrong until she heard Clarence run into, and break a glass table.
														After realizing that Clarence was hallucinating, Shirley pressed their SOS button on her Snapfon ezTWO.
                                                        sosPlus team member Amy responded to Shirley's call for help and notified their hospice. Immediatly, hospice arrivd and secured Clarence's oxygen tube to restore his flow back to normal. "I thought
														they did superb in getting Clarence the help he needed," Shirley said, "A lot faster than some
														hospitals I've been to!" She continued.
													</div>
												</div>
												<div class='hero'>
													<div class='agent'>
														<img src="/images/onecall/Jason-Rodriguez.png" alt="sosPlus Response Agent :Jason R."><br />
														Response Agent:<br />
														Jason R.
													</div>
													<div class='testimonial normalBigText'>
														<h2>ON KITCHEN FLOOR & APPLIANCES IGNITE A FIRE - Jul 19 2013</h2>
														<span class='ezGreen normalText'>NEW FAIRFIELD, CT</span><br />
														Eleanor prefers her English muffins to be "burnt and crunchy." Frequently, she will put them back in the toaster until they are burnt.
														<br><br>
														On July 11th, at 8:30am, Eleanor had her English muffin toasting, when all of a sudden sparks projected out of the toaster. Eleanor tried to pull the cord away from the outlet. As she attempted to do so, a burst of electrical energy came from the toaster and ignited other appliances around her. This caused Eleanor to fall down on the floor. She immediately pressed her SOS button on her Snapfon ezTWO. sosPlus team member Jason responded to her call, but there was no response. Erring on the side of caution, he dispatched the paramedics to Eleanor.
														<br><br>
														Upon arrival, EMS discovered that the fire had spread over the counter top and Eleanor had crawled into the living room to avoid the fire. EMS quickly extinguished the fire while tending to Eleanor's injuries, giving her oxygen for the amount of smoke she had inhaled.
														<br><br>
														"She could've died!" Vicky, Eleanor's daughter commented. "But you guys sent help there so quick that you potentially saved her life!" she continued.
                                                        sosPlus Agents later learned that Eleanor is recovering well from her injuries.
														<br><br>
														We think Vicky says it best, "For anyone who lives alone... just get one!"
													</div>
												</div>
												<div class='hero'>
													<div class='agent'>
														<img src="/images/onecall/Jessica-Johnson.png" alt="sosPlus Response Agent :Jessica J."><br />
														Response Agent:<br />
														Jessica J.
													</div>
													<div class='testimonial normalBigText'>
														<h2>WATER HEATER CAUSES THREATENING SITUATION - Jun 12 2013</h2>
														<span class='ezGreen normalText'>LOUISVILLE, KY</span><br />
														I usually do not get to bed till late at night. At around 4:30 am I finally felt ready to go to sleep when all the sudden sirens started going off.
														Being 84 years old, this was a shock to my system. My heart was pounding so hard, I didn't know what was going on and when I was finally able to
														get out of bed and walked into the living room, I opened my bedroom door, I stepped in a puddle of water! I looked up and water was coming out of
														my ceiling fan like something out of a horror picture! I went to check out my window to see if it was raining. It wasn't. I heard a loud cracking
														sound coming from my kitchen. My toaster was sparking! I began to fear for my life."
														"I thought, "What could I do?" The home phone didn't seem to be working. Then the thought came to me! "I have my Snapfon!" So I pressed my SOS
														button and got a hold of a wonderful young woman who calmed me down and reassured me that help was on the way. When the fire department arrived,
														they immediately shut off my power. Soon after, my daughter arrived, and helped me grab some things from my house and took me to her home. I was
														later told that the cause of all the water was from a water heater that broke."
														Magdalene says it best: "If you live alone, you need one!" "If I didn't have one I would be afraid to live alone."
													</div>
												</div>
												<div class='hero'>
													<div class='agent'>
														<img src="/images/onecall/Kelbi-Underwood.png" alt="sosPlus Response Agent :Kelbi U."><br />
														Response Agent:<br />
														Kelbi U.
													</div>
													<div class='testimonial normalBigText'>
														<h2>WOMAN BECOMES ADVOCATE FOR SOSPLUS - May 22 2013</h2>
														<span class='ezGreen normalText'>BIRMINGHAM, AL</span><br />
														"I didn't think I would ever have to use it...but if it hadn't been for that little SOS button, I wouldn't be here today!" Now I tell
														everyone to get an ezTWO! Annie told Snapfon after she survived a life threatening experience back in March.
														<br><br>
														Annie progressively felt worse throughout the day.  She tried to lay down for a bit to see if that would help, but nothing seemed to make her feel any better.  As she then headed to the bathroom, her legs gave out from under her and she blacked out. "I wasn't sure how long I had been out, but I just prayed saying: "Lord give me the strength to press my SOS button," and he did."
														<br><br>
                                                        SosPlus team member Kelbi attempted to communicate with Annie, not knowing that she had blacked out again and was lying on the floor. Erring on the side of caution, Kelbi sent police and paramedics to her home.
														<br><br>
														Upon arrival, EMS was able to help Annie regain consciousness. They quickly assessed her vitals. After getting the results back, they knew they quickly needed to get her to the hospital. At that point she had tested significantly low for her blood pressure (anything lower and she could've gone into a coma).
													</div>
												</div>
												<div class='hero'>
													<div class='agent'>
														<img src="/images/onecall/Hannah-Sak.png" alt="sosPlus Response Agent :Hannah S."><br />
														Response Agent:<br />
														Hannah S.
													</div>
													<div class='testimonial normalBigText'>
														<h2>WOMAN FALLS, FINDS WORSE HEALTH ISSUES - MAY 02 2013</h2>
														<span class='ezGreen normalText'>BOONVILLE, NY</span><br />
														I need help, I need help!" was the only expression sosPlus team member Hannah received from Marjorie on May 5th at approximately 10am.
														<br><br>
														Marjorie went about her day like any other. Growing weaker in strength and energy as the day proceeded. When she had to use the restroom, she realized that her strength had all but left her, so she pressed her pendant. Within moments, sosPlus team member Hannah had heard Marjorie's plea and sent help to her home.
														<br><br>
														Within minutes, EMS arrived at Marjorie's home. Assessing her vitals they knew something else was wrong, so they transported her to the hospital for further tests.
														<br><br>
														"If she hadn't pressed her medical pendant, it might have been too late for the doctors to realize that Marjorie's health status had changed," said Beverly, Marjorie's daughter. Beverly later told sosPlus that if she hadn't been at the hospital her current medication would have worsened her newly discovered illness.
													</div>
												</div>
												<div class='hero'>
													<div class='agent'>
														<img src="/images/onecall/Daniel-Mooth.png" alt="sosPlus Response Agent :Daniel M"><br />
														Response Agent:<br />
														Daniel M.
													</div>
													<div class='testimonial normalBigText'>
														<h2>BLEEDING PROFUSELY- MAN PRESSES SOS - FEB 07 2013</h2>
														<span class='ezGreen normalText'>MILTON, PA</span><br />
														On February 2, 2013, at approximately 4PM, William, of Milton, Pennsylvania pressed his medical button. William was immediately connected with sosPlus team member Daniel. He advised Daniel that he couldn't move. William had fallen and was bleeding profusely. Daniel quickly dispatched the paramedics and then let the frightened subscriber know that help was on the way.  William was worried that the response would take too long as he lives in a remote and rural area.  Daniel comforted William and calmed him down as he reassured him that help would arrive soon.
														<br><br>
                                                        SosPlus later confirmed that William was transported to a nearby hospital for further medical attention. We thank Daniel for his calm and courteous response that not only helped get William the help that he desperately needed, but for also calming the patient down until help arrived.
													</div>
												</div>
												<div class='hero'>
													<div class='agent'>
														<img src="/images/onecall/Michael-Brawner.png" alt="sosPlus Response Agent :Michael Brawner."><br />
														Response Agent:<br />
														Hannah S.
													</div>
													<div class='testimonial normalBigText'>
														<h2>SOSPLUS TEAM MEMBER HELPS ELDER ABUSE VICTIM - Dec 6 2012</h2>
														<span class='ezGreen normalText'>PHILIDELPHIA,PA</span><br />
														Can you imagine being beat up with no way to call for help? What if it was your own grandchild that beat you? That's exactly what happened to Delores, of Philadelphia, Pennsylvania, on December 6, 2012. Just after 10:30PM, Delores triggered a medical alarm, of which was received and handled by sosPlus operator Michael B. Delores explained to Michael that she had tried calling 911 herself but was unable to because "he took the home phones from me...that's why I had to notify you (via her Snapfon ezTWO SOS button)... he then beat me and took the Snapfon with him."
														<br><br>
														Luckily the grandson failed to understand that taking the phone away would have no effect on the SOS sosPlus system, thus Delores was able to press her button before he grabbed the phone and she was still able get the help she needed.
														<br><br>
														Michael after hearing the situation through the speakerphone immediately dispatched both the police department and paramedics to Delores' address. Michael later found out from a contact that Delores has been trying to evict her grandson from her condo and he was violent. sosPlus confirmed that Delores was able to receive the help she needed. We thank Michael, who helped Delores in this time of need, allowing her access to help, even after the her Snapfon had been taken. If she did not own a Snapfon ezTWO with sosPlus, she never would have been able to reach out for help.
													</div>
												</div>
												<div class='hero'>
													<div class='agent'>
														<img src="/images/onecall/Brandy-Hinderman.png" alt="sosPlus Response Agent :Brandy H"><br />
														Response Agent:<br />
														Brandy H.
													</div>
													<div class='testimonial normalBigText'>
														<h2>Life Saved - Nov 21 2012</h2>
														<span class='ezGreen normalText'>AVANDALE, AZ</span><br />
														On October 3, 2012 at 05:28AM, Mary F. of Avandale, Arizona pressed her medical button. sosPlus operator, Brandy H., received the alarm within four seconds and immediately connected to the Snapfon ezTWO. Unfortunately Brandy could make no contact with Mary over her Snapfon ezTWO, so she tried to reach Mary on the home phone. Yet Brandy still remained unable to reach Mary to see what was wrong. She then dispatched the paramedics to Mary's residence.
														<br><br>
														What Brandy didn't know was that Mary was experiencing a life threatening emergency and couldn't communicate...but she could press her SOS button.  Mary's daughter, Gayle, later informed us that had Brandy not responded to Mary's button press as she did, Mary would have died.  The family was obviously more than grateful for the service provided by Mary's sosPlus on her Snapfon ezTWO, and Brandy's response.
														<br><br>
														We thank sosPlus team member Brandy H. for her dedicated service to Mary, giving her the added confidence that getting help when you need it is just as easy as her snapfon ezTWO!
													</div>
												</div>

											</td>
										</tr>

									</table>
					<!-- ONE CALL TABLE END -->

								</td>
							</tr>
						</table>

					</td>
				</tr>
			</table>
            <div style='text-align: center;'>
            <div><img src="/images/sosPlus-logo.jpg" alt="Effective January 1, 2014 oneCall Mobile will be renamed sosPlus Mobile"></div>
            <div>Effective January 1, 2014 oneCall Mobile will be renamed sosPlus Mobile</div>
            </div>
			<?php include_once(DIR_FS_ROOT . '/includes/pageFooter.php'); ?>
		</div>
		<script type="text/javascript" src="<?= $mainSitePath ?>js/seniortechllc_slideshow_2.js"></script>
		<script type="text/javascript">
			$(document).ready(function() {
				var slides = $('#slides');
				$.extend(slides, slideShow);
				slides.crossfade=1000;
				slides.addSlide("src='<?= $mainSitePath; ?>images/onecall/slides/01-sos-plus-when-every-second-counts.jpg' alt='sosPlus when every second counts!' data-timeout=4000");
				slides.addSlide("src='<?= $mainSitePath; ?>images/onecall/slides/02-sos-plus-certified-response-agents.jpg' alt='Certified US Response Agents' data-timeout=4000");
				slides.addSlide("src='<?= $mainSitePath; ?>images/onecall/slides/03-24-7-sos-plus-piece-of-mind.jpg' alt='Snapfon ezTWO bring you peace of mind' data-timeout=4000");
				slides.addSlide("src='<?= $mainSitePath; ?>images/onecall/slides/04-sos-plus-all-the-help-you-need-slide.jpg' alt='Snapfon eztwo with sosPlus, all the help you need!' data-timeout=4000");
				slides.show();
			});
		</script>
	</body>
</html>
