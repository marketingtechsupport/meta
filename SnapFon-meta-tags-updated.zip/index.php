<?php
ob_start();
chdir("catalog");
require('includes/application_top.php');
$mainSitePath = '';
?>
<!doctype html>
<html>
<head>
    <? //define( 'SUBDIR', 'about-snapfon-products'); ?>
    <?php include_once(DIR_FS_ROOT . '/includes/meta.php'); ?>
    <?php include_once(DIR_FS_ROOT . '/includes/executable.php'); ?>
    <meta name="msvalidate.01" content="6D4141618BD8F3935332908F35A8A731" />
    <meta name="msvalidate.01" content="CE41F83ADBE54FE4CBEC6CF4672DD3E9" />
    <meta name="description" content="Simple cell phones for elderly people. Get the ezTWO cell phone for seniors that come with plans that suit the budget. Find out why senior citizens love it.">
    <meta name="keywords" content="senior cell phone, cell phones for the elderly, cell phones for elderly people, cell phone plans for seniors, simple cell phones for seniors, phones for seniors, cell phones for seniors, cell phones for senior citizens, cell phone for senior citizens, cell phone for seniors">
    <?php include_once(DIR_FS_ROOT . '/includes/links.php'); ?>

    <link rel="stylesheet" href="<?= $mainSitePath ?>fancybox/jquery.fancybox-1.3.1.css" type="text/css" media="screen" />

    <link rel="stylesheet" href="<?= $mainSitePath ?>catalog/snapcatalog.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?= $mainSitePath ?>styles/seniortechllc_slideshow.css" type="text/css" media="screen" />
    <style>
      .slideShow .button {
        position: absolute;
        bottom: 10px;
        right: 17px;
      }
    </style>
    <script type="text/javascript">
        (function() {
            var po = document.createElement("script"); po.type = "text/javascript"; po.async = true;
            po.src = "https://apis.google.com/js/plusone.js?publisherid=100585663466201424230";
            var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(po, s);
        })();
    </script>
    <title>ezTWO Cell Phones for Elderly People | Call (800) 937-1532 | Snapfon</title>
<!-- ob_styles -->
</head>
<body>
<a href="https://plus.google.com/100585663466201424230" rel="publisher"></a>
<img src="https://secure.adnxs.com/seg?add=799496&t=2" width="1" height="1" />
<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/offsite_event.php?id=6006195267217&amp;value=0" /></noscript>
<?php include(DIR_FS_ROOT . 'analyticstracking.php'); ?>
<div id='pageBody'>
    <?php 
    include_once(DIR_FS_ROOT . '/includes/pageHeader.php');
    $coverageChecker = true;
    require_once(DIR_FS_ROOT . '/senior-cell-phone-plans/plans.php');
    ?>
    <div id='slides' class='slideShow' style='width: 975px; height: 446px'>
      <div class='selectors'></div>
      <span class='button' onClick='window.location = "/shop/";'>Shop Now</span>
    </div>
    <hr></hr>
    <div style='text-align: center;'>
    <img src="/images/sosplus-help-at-the-touch-of-a-button.png" alt="help at the touch of a button" onClick='doAddOneMore( 1, <?= CURRENT_PHONE_ID_WITH_SERVICE ?>)' />
    <img src="/images/snapfon-nationwide-coverage.png" alt="Click to check our nationwide coverage map" class="coverageChecker"/>
    <img src="/images/farewell-to-the-snapfon-ezone.png" alt="Farewell to the Snapfon ezONE, the original easy to use senior cell phone"/>
    </div>
    <table align="center" style="margin-left:20px;margin-right:10px;">
        <tr>
            <td align="left"><img src="/images/homepage_new/eztwo-homepage-product.jpg" alt="big button senior cellphone" border="0" /></td>

            <td valign="top">

                <table>
                    <tr>
                        <td colspan="2" align="center">
                            <a href="/support/snapfon-warranty.php"><h1 style='display: inline; vertical-align: top;'>Try the Snapf&#333n ezTWO for 30 Days Risk Free!</h1></a>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" valign="top" width="275">
                            <ul class="accentColorList">
                                <li><span>Big Buttons &amp; Numbers</span></li>
                                <li><span>Easy to read full color screen</span></li>
                                <li><span>Enhanced volume &amp; Speaker phone</span></li>
                                <li><span>Speaking keypad</span></li>
                                <li><span>Hearing Aid Compatible (M3/T3)</span></li>
                                <li><span>Bluetooth enabled</span></li>
                                <li><span>Extra-long battery life</span></li>
                                <li><span>SOS button <a href="/services/onecall_mobile.php" alt="oneCall mobile, the perfect protection plan for seniors!">(sosPlus Mobile)</a></span></li>
                                <li><span>8 speed dial keys</span></li>
                                <li><span>Camera &amp; Color photo album</span></li>
                                <li><span>LED flashlight</span></li>
                                <li><span>4 Alarm Modes</span></li>
                                <li><span><a href="/about-snapfon-products/bigbuttoncellphones" alt="the perfect cell phone for seniors">Learn more...</a></li>
                            </ul>
                        </td>
                        <td align="center" valign="top">
                            <p>Try a Snapf&#333n&reg; ezTWO RISK FREE for 30 days and
                                discover why it is the best selling cellphone for seniors.
                                It is packed with features designed with seniors in mind,
                                with affordable cellular plans and services, tailored to fit a seniors
                                lifestyle and budget!
                            </p>
                            <span class="ezGreen bigOlText">$<?= floor( PRICE_WITH_PLAN) ?></span><span class="ezGreen bigText" style="vertical-align:top;">.<?= 100 * (PRICE_WITH_PLAN - floor(PRICE_WITH_PLAN)) ?>*</span><br>
                            <span class="ezGreen">
                            with any Basic Plan<br />
<!--                            or<br />
                           <strong>FREE with any Premium Plan</strong><br /> -->
                            </span><br />
                            <span id='addPhoneWithService' class='button' onClick='doAddOneMore( 1, <?= CURRENT_PHONE_ID_WITH_SERVICE ?>)'>Add to Cart</span>
                            <?php /*
                            <br />
                            * When phone is purchased with an activated service plan.<br />
                            */ ?>
                            <?php /* !--Phones purchased without service are $<?= PRICE_WITHOUT_PLAN ?>. */ ?>
                        </td>
                    </tr>

                    <tr>
                        <td colspan="2" align="center">
                            <div class="ezGreen" style="font-size: 24px; font-weight: bold;">
                                <?= (IN_STOCK != 'IN_STOCK') ? IN_STOCK . '<br />' : ''; ?>
                                <br />
                                Free Accessory + <?= BONUS_MINUTES ?> Bonus minutes with activation!*
                            </div>
                        </td>
                    </tr>
                </table>
            </td>
    </table>
    <div class="orange"></div><?php /* Orange line separator */ ?>
    <table id="frontPageInfo" style="margin:10px" cellspacing="20">
        <tr>
            <td width="300" valign="top">
                <span class="bigText ezGreen"><h2>Why Choose Snapf&#333n<sup>&reg;</sup>?</h2></span>

                <p>At Snapf&#333;n&reg;, we always have seniors in mind. We have designed the industry leading ezTWO senior cell phone and our affordable cellular service plans to fit the individual needs of senior citizens. We are a cell phone company that gets YOU.</p>

                <p>All of us at Snapf&#333;n&reg; know that learning to use technology can be challenging for anyone. We kept that in mind when designing the ezTWO senior cell phone. Instead of focusing on smaller, faster, and more complicated devices, the Snapf&#333;n&reg; ezTWO was designed with ease of use in mind. Big buttons, enhanced sound, easy to navigate menus, Bluetooth&reg;, hearing aid compatability, and our exclusive SOS button transforms this simple phone into a life changing device for seniors.</p>
            </td>

            <td>
                <span class="bigText ezGreen"><h2>Plans and services designed for seniors</h2></span>

                <p>Creating a senior-friendly cell phone isn't our only priority. Our cellular service plans feature No Contract, are tailored to how seniors use cell phones, and are powered by America's most reliable nationwide GSM network.</p>
                <p>Our Basic Flex Plan, starting at only <?= money_format('$%i', BASIC_FLEX_PLAN_PRICE); ?>, provides 130 minutes a month and unlimited rollover minutes that never expire. <?= (BONUS_MINUTES > 0) ? 'Sign up now and get ' . BONUS_MINUTES . ' free bonus minutes!' : ''; ?></p>
                <p>If you just don't want to worry about limitations and you do want the added protection of our new oneCall Mobile Monitoring Service, the Premium Unlimited plan features unlimited talk and text, for only <?= money_format('$%i', PREMIUM_UNLIMITED_PLAN_PRICE); ?> and 24 hour emergency monitoring.</p>
                <p>All of our service plans include our ezProtection Handset Replacement Program. Whatever your needs, you will find that Snapf&#333;n&reg; has the perfect plan to fit your needs and budget.</p>

                <span class="bigText ezGreen"><h2>The perfect cell phone for seniors!</h2></span>
                <p>With today's advances, seniors live more independent lives. A cell phone is an invaluable and necessary tool for extending independence and safeguarding yourself or your loved one. The Snapf&#333;n&reg; ezTWO combines the reliability of a standard cell phone with big buttons, a bright screen, large fonts, enhanced rings and sound, and a simple to navigate menu. Combining these simple to use features with Snapf&#333;n's unique SOS button (available with optional oneCall Mobile Mobile Monitoring Service), insures that help is only a button press away in an emergency.</p>
                <p>The Snapf&#333;n&reg; is easy to see, easy to hear, and easy to use. Let us help to keep you or your loved one safe and healthy.</p>

            </td>
        </tr>
    </table>
    <!-- END index.php TABLE -->
    <div>
        <? include_once( DIR_FS_ROOT . 'includes/pageFooter.php'); ?>
    </div>
    <!-- pre>
<? //= __FILE__ ?>
<? // print_r($browser_info); ?>
    </pre -->
<!-- ob_scripts -->
    <script type="text/javascript" src="<?= $mainSitePath ?>fancybox/jquery.fancybox-1.3.1.pack.js"></script>
    <script type="text/javascript" src="<?= $mainSitePath ?>js/plans.js"></script>
    <script type="text/javascript">
      var fb_param = {};
      fb_param.pixel_id = '6006195267217';
      fb_param.value = '0.00';
      (function(){
        var fpw = document.createElement('script');
        fpw.async = true;
        fpw.src = (location.protocol=='http:'?'http':'https')+'://connect.facebook.net/en_US/fp.js';
        var ref = document.getElementsByTagName('script')[0];
        ref.parentNode.insertBefore(fpw, ref);
      })();
    </script>
    <script type="text/javascript" src="<?= $mainSitePath ?>js/seniortechllc_slideshow_2.js"></script>
    <script type="text/javascript">
			$(document).ready(function() {
				var slides = $('#slides');
				$.extend(slides, slideShow);
				slides.crossfade=1000;
//				slides.addSlide("src='/images/homepage_new/slides/1-breast-cancer-awareness-month.png' alt='Show your support!' data-timeout=5500");
//				slides.addSlide("src='/images/homepage_new/slides/3-cellphone-for-seniors.png' alt='Snapfon ezTWO oneCall Mobile Urgent Monitoring Service now available in with the Snapfon ezTWO' data-timeout=5500");
//				slides.addSlide("src='/images/homepage_new/slides/5-senior-cellphone-ezprotection.png' alt='Snapfon ezTWO The best cellular protection warranty on the market today!' data-timeout=5500");
//				slides.addSlide("src='/images/homepage_new/slides/1-Easy-just-got-easier-V2.png' alt='Snapfon ezTWO Easy just got easier!' data-timeout=5500");
//                slides.addSlide("src='/images/homepage_new/slides/snapfon-thanksgiving-slide.jpg' alt='Happy thanksgiving from Snapfon ezTWO Easy-to-see,easy-to-use senior cell phone' data-timeout=12000");
                slides.addSlide("src='/images/homepage_new/slides/1-easy-to-see-easy-to-use.png' alt='Snapfon ezTWO Easy-to-see,easy-to-use senior cell phone' data-timeout=12000");
//				slides.addSlide("src='/images/homepage_new/slides/more-than-just-a-senior-cell-phone.png' alt='Snapfon ezTWO is more than just an easy to use senior cell phone, it's the easy way to had mobile monitoring protection 24/7!' data-timeout=7000");
				slides.addSlide("src='/images/homepage_new/slides/sosplus-certified-response-agents.jpg' alt='sosplus certified response agents' data-timeout=10000");
                slides.addSlide("src='/images/homepage_new/slides/6-low-battery-warning-system2.png' alt='Snapfon ezTWO low battery warning system' data-timeout=8000");
				slides.show();
			});
    </script>
  </body>
</html>
<?php
  $buffer = ob_get_contents();
  ob_end_clean();

if (true) { // move styles to <head> and <script> just before </body>
  $movers = array(
    // Setup script matches and exclusions.
    'ob_scripts' => array(
      'pattern' => ':<script[^>]*>.*</script>:isU',
      'exclude' => '/ANS_customer_id|authorize/',
      'matches' => '',
    ),
    // Setup style matches and exclusions.
    'ob_styles' => array(
      'pattern' => ':<style[^>]*>.*</style>:isU',
      'exclude' => '', // Nothing is excluded
      'matches' => '',
    ),
  );

  foreach($movers as $mover_key => &$mover_value) {
    preg_match_all($mover_value['pattern'], $buffer, $mover_value['matches']);

    if ($mover_value['exclude'] != '')
      foreach($mover_value['matches'][0] as $key => &$value)
        if (preg_match($mover_value['exclude'], $value))
          $value = ''; // excluded
        else
          $buffer = str_replace($value, '', $buffer);
    $buffer = str_replace("<!-- $mover_key -->", implode("\n", $mover_value['matches'][0]), $buffer);
  }

  // remove blank lines
  $buffer = split("\n", $buffer);
  foreach($buffer as &$value)
    if (!preg_match('/^\\s*$/',$value))
      $nbuffer[] = $value;
  echo implode("\n", $nbuffer);

  } else {
    echo "$buffer";
  }
?>
