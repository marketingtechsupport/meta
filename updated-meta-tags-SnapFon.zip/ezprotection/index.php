<? 
chdir("../catalog");
require("includes/application_top.php"); 
?>
<!doctype html>
<html>
	<head>
		<? define( 'SUBDIR', 'about-snapfon-products'); ?>
        <? include_once( 'includes/meta.php'); ?>
        <? include_once( '../includes/executable.php'); ?>
        <? //include_once( $mainSitePath . 'includes/meta.php'); ?>
        <meta name="description" content="A senior citizen with an active lifestyle? Buy any of Snapfon�s phones for seniors, and not worry about damage wherever you go with the help of ezProtection.">
		<meta name="keywords" content="phones for seniors">
		<link rel="stylesheet" type="text/css" href="/styles/snapfon.css">
		<link rel="stylesheet" type="text/css" href="/catalog/snapcatalog.css">
		<? include_once( $mainSitePath . 'includes/links.php'); ?>

		<? // Crank up jquery ?>
		<? // oops! Actually, dojo starts jquery. So the next line isn't needed really ?>
		<!-- script type="text/javascript" src="http://code.jquery.com/jquery-1.4.2.min.js"></script -->
		
		<? // some of the following includes can come out, on a page by page basis ?>
		<script type="text/javascript" src="<?= $mainSitePath ?>fancybox/jquery.fancybox-1.3.1.pack.js"></script>
		<link rel="stylesheet" href="<?= $mainSitePath ?>fancybox/jquery.fancybox-1.3.1.css" type="text/css" media="screen" />

		<? // but these should satay in for the pages that need ajax or dojo ?>
		<link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/dojo/1.5/dojo/resources/dojo.css" />
		<link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/dojo/1.5/dijit/themes/claro/claro.css" />
		<script src="http://ajax.googleapis.com/ajax/libs/dojo/1.5/dojo/dojo.xd.js" type="text/javascript"></script>

		<title>ezProtection Handset Replacement for Seniors | Shop Now | Snapfon</title>

		<script type="text/javascript">
			// Uncomment these for dialogs
			/*
			dojo.require("dijit.form.Button");
			dojo.require("dijit.form.CheckBox");
			dojo.require("dijit.form.ComboBox");
			dojo.require("dijit.Dialog");
			dojo.require("dijit.layout.TabContainer");
			dojo.require("dijit.layout.ContentPane");
			*/
			// This function is for the various "add to cart buttons around the site.
			function doAddItem( product_id) {
				dojo.xhrPost(
					{
					url: "<?= $mainSitePath ?>catalog/ajax/cart_actions_2.php",
					timeout:3000,
					content: {op:"add_item", pid:product_id, qty: 1},
					handleAs: "json",
					handle: function(resultData,ioArgs) {
						if (resultData.result == "success") {
							if (resultData.newCartData != null) {
								}
							else {
								}
							}
						else {
							alert(resultData.Message)
							}
						}
					})
				}
		</script>
        <script type="text/javascript">
            var fb_param = {};
            fb_param.pixel_id = '6006195267217';
            fb_param.value = '0.00';
            (function(){
                var fpw = document.createElement('script');
                fpw.async = true;
                fpw.src = (location.protocol=='http:'?'http':'https')+'://connect.facebook.net/en_US/fp.js';
                var ref = document.getElementsByTagName('script')[0];
                ref.parentNode.insertBefore(fpw, ref);
            })();
        </script>
        <noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/offsite_event.php?id=6006195267217&amp;value=0" /></noscript>
	</head>
	<body>
	<div id='pageBody'>
		<? include_once( $mainSitePath . 'includes/pageHeader.php'); ?>
		<table cellpadding="0" cellspacing="0">
			<tr>
				<td id='pageBodyCell'>
					
					<!-- START handset_protection TABLE --> 
					<table align="center" width="906">
						<tr>
							<td align="right" style='text-align: right;'>
								<a href="/shop/"><span class='button'>Shop Now</span></a>
							</td>
						</tr>
						<tr>
							<td style="background-image:url('/images/handset_protection/eztwo-handset-replacement-dog-banner.jpg');background-repeat:no-repeat;width:902px;height:244px;">
								
								<div style="width:410px;height:200px;background-color:transparent;position:relative;left:465px;top:10px;">	
									<h1><span class="ezOrange">ez</span><span class="ezGreen biggerText">Protection Handset Replacement</span></h1>
									<span class="normalBigText">
									We know that accidents happen. That's why all of our service plans include our exclusive
                                        ezProtection Handset Replacement Program which covers many forms of physical damage including water, drops and most things in between.<br>
                                        Click <a class="ezGreen" href="/support/ezprotection-tc.php" alt="ezProtection terms and conditions">here</a> for details.
									</span>
								</div>
							</td>
						</tr>
						
						<tr>
							<td>
								<span class="normalBigText">
								<br>
								<h3>At Snapf&#333n, your satisfaction is our commitment.  We are so committed that we created the only<br> NO deductible handset replacement program in the industry!
                                     Thats's right - NO deductible! With our<br> 30 Day Risk Free Guarantee and ezProtection, there is no reason not to give Snapf&#333n
								a try!</h3>
								<br><br>
								</span>
							</td>
						</tr>
						
						<tr>
							<td style="background-image:url('/images/handset_protection/eztwo-wet-handset-banner.jpg');background-repeat:no-repeat;width:902px;height:248px;">
								
								<div style="width:490px;height:200px;background-color:transparent;position:relative;left:25px;top:10px;">
                                    <h1><span class="ezOrange biggerText">Coverage you can count on!</span></h1>
									<span class="normalBigText">
									With no deductible and pre-paid shipping both ways, ezProtection makes relying on your Snapf&#333n
                                        a snap.<br><br> For a full explanation of coverage and exclusions, please view the ezProtection Terms & Conditions <a class="ezGreen" href="/support/ezprotection-tc.php" alt="ezProtection terms and conditions">here.</a>
									</span>
								</div>
							</td>
						</tr>
					
					<tr>
						<td align="right" style='text-align: right;'>
								<a href="/shop/"><span class='button'>Shop Now</span></a>
						</td>
					</tr>
					
					</table>
					
					<!-- END handset_protection TABLE -->
					
					
					
					
					
					
				</td>
			</tr>
		</table>
		<? include_once( $mainSitePath . 'includes/pageFooter.php'); ?>
	</div>
	</body>
</html>
