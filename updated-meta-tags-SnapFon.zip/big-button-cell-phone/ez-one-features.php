<? //ini_set('display_errors','1'); ?>
<?
	chdir("../catalog/");
	require('includes/application_top.php'); 
?>
<!doctype html>
<html>
	<head>
		<? define( 'SUBDIR', 'about-snapfon-products'); ?>
		<? include_once( '../includes/executable.php'); ?>
        <? include_once( 'includes/meta.php'); ?>
        <? //include_once( $mainSitePath . 'includes/meta.php'); ?>
        <meta name="description" content="Simple senior cell phone with medical alert features and low cost cell phone plans designed for the active senior lifestyle, perfect gift idea for the mobile senior!">
		<?
		
			$category_id = SHOW_ACCESSORIES_ID;
			if (isset( $showAcc) && ($showAcc == "1")) {
				$category_id = SHOW_ACCESSORIES_ID;
			}

			if (!isset($category_id) || ($category_id == "") || ($category_id == 0)) {
				if ($category_id != SHOW_ACCESSORIES_ID) {
					$category_id = SHOW_ALL_ID;
				}
			}
//if (isset( $_GET['phonesToExclude'])) {
//	$_SESSION['phonesToExclude'] = $_GET['phonesToExclude'];
//	}

// the following cPath references come from application_top.php
  $category_depth = 'top';
  if (isset($cPath) && tep_not_null($cPath)) {
    $categories_products_query = tep_db_query("select count(*) as total from " . TABLE_PRODUCTS_TO_CATEGORIES . " where categories_id = '" . (int)$current_category_id . "'");
    $cateqories_products = tep_db_fetch_array($categories_products_query);
    if ($cateqories_products['total'] > 0) {
      $category_depth = 'products'; // display products
    } else {
      $category_parent_query = tep_db_query("select count(*) as total from " . TABLE_CATEGORIES . " where parent_id = '" . (int)$current_category_id . "'");
      $category_parent = tep_db_fetch_array($category_parent_query);
      if ($category_parent['total'] > 0) {
        $category_depth = 'nested'; // navigate through the categories
      } else {
        $category_depth = 'products'; // category has no products, but display the 'no products' message
      }
    }
  }

		
		?>
			<?  //include_once( "../catalog/includes/configure.php");
			$qCon = mysql_connect( DB_SERVER, DB_SERVER_USERNAME, DB_SERVER_PASSWORD);
			mysql_select_db( DB_DATABASE);
		?>
		<? include_once( $mainSitePath . 'includes/links.php'); ?>
		<link rel="stylesheet" type="text/css" href="/catalog/snapcatalog.css">

		<? // Crank up jquery ?>
		<? // oops! Actually, dojo starts jquery. So the next line isn't needed really ?>
		<!-- script type="text/javascript" src="http://code.jquery.com/jquery-1.4.2.min.js"></script -->
		
		<? // some of the following includes can come out, on a page by page basis ?>
		<script type="text/javascript" src="<?= $mainSitePath ?>fancybox/jquery.fancybox-1.3.1.pack.js"></script>
		<link rel="stylesheet" href="<?= $mainSitePath ?>fancybox/jquery.fancybox-1.3.1.css" type="text/css" media="screen" />
		<script type="text/javascript" src="<?= $mainSitePath ?>js/swfobject.js"></script>

		<? // but these should satay in for the pages that need ajax or dojo ?>
		<link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/dojo/1.5/dojo/resources/dojo.css" />
		<link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/dojo/1.5/dijit/themes/claro/claro.css" />
		<script src="http://ajax.googleapis.com/ajax/libs/dojo/1.5/dojo/dojo.xd.js" type="text/javascript"></script>

		<!-- <script src='../includes/flot/jquery.flot.js' type="text/javascript"></script> -->

		<title>Big Button Cell Phones | Features for Active seniors | Snapfon</title>
		<script type="text/javascript">
			// Uncomment these for dialogs
			
			dojo.require("dijit.form.Button");
			dojo.require("dijit.form.CheckBox");
			dojo.require("dijit.form.ComboBox");
			dojo.require("dijit.Dialog");
			dojo.require("dijit.layout.TabContainer");
			dojo.require("dijit.layout.ContentPane");
			
			$(document).ready(function() {
	$.fn.restrict = function(pattern, allowed){
	    // default to allow backspace, delete, tab, escape, enter
	    allowed = allowed || [0, 46, 8, 9, 27, 13];
	    $(this).keypress(function(event){
	        if(event.which) {
	            var key = event.which;
	            if($.inArray(key, allowed) > -1){
	              return true;
	            }
	            var character = String.fromCharCode(key);
	            if(pattern.test(character)){
	                return true;
	            }
	            event.preventDefault();
	            return false;
	        };
	    });
	    return this;
	};

	$('input.numeric').restrict(/\d/);


		$planpicker = $('#planpicker').dialog( {
			autoOpen:false, 
			closeOnEscape:true, 
			modal:true,
			width: 840,
			height:872,
			resizable: false,
			title:false
			});
		$activationpicker = $('#activationpicker').dialog( {
					autoOpen:false,
					closeOnEscape:true,
					modal:true,
					width: 675,
					height:309,
					resizable: false,
					title:false
					});
		$vidPlayer = $('#vidPlayer').dialog( {
					autoOpen:false,
					closeOnEscape:true,
					modal:true,
					width: 675,
					height:470,
					resizable: false,
					title:false
					});
		$ezContactPicker = $('#ezContactPicker').dialog( {
					autoOpen:false,
					closeOnEscape:true,
					modal:true,
					width: 900,
					height:425,
					resizable: false,
					title:false
					});
		$phonewiz1 = $('#phonewiz-1').dialog( {
			autoOpen:false, 
			closeOnEscape:true, 
			modal:true,
			width: 700,
			height:525,
			resizable: false,
			title:false
			});	

		$phonewiz2 = $('#phonewiz-2').dialog( {
			autoOpen:false, 
			closeOnEscape:true, 
			modal:true,
			width: 700,
			height:525,
			resizable: false,
			title:false
			});
			
		$phonewiz3 = $('#phonewiz-3').dialog( {
			autoOpen:false, 
			closeOnEscape:true, 
			modal:true,
			width: 700,
			height:525,
			resizable: false,
			title:false
			});

		$phonewiz4 = $('#phonewiz-4').dialog( {
			autoOpen:false, 
			closeOnEscape:true, 
			modal:true,
			width: 700,
			height:525,
			resizable: false,
			title:false
			});
	
		$batwiz = $('#batwiz').dialog( {
			autoOpen:false, 
			closeOnEscape:true, 
			modal:true,
			width: 625,
			height:710,
			resizable: false,
			title:false
			});
			
		$hpwiz = $('#hpwiz').dialog( {
			autoOpen:false, 
			closeOnEscape:true, 
			modal:true,
			width: 625,
			height:710,
			resizable: false,
			title:false
			});
			
		$('#phonewiz-1-yes').click(function() {
			$('#phonewiz-1').dialog("close");
			$('#phonewiz-2').dialog("open");
			$('#iwantservice').val('1')
			})
		
		$('#phonewiz-1-no').click(function() {
			$('#phonewiz-1').dialog("close");
			$('#phonewiz-3').dialog("open");
			$('#iwantservice').val('0')
			});

		$('#phonewiz-2-yes').click(function() {
			$('#phonewiz-2').dialog("close");
			doAddPhoneWithServiceDiscount( false);
		//	doAddPhoneOnly( false);
			doAddRTUOnly( false);
			$('#iwantservice').val('1')
			});

		$('#phonewiz-2-no').click(function() {
			$('#phonewiz-2').dialog("close");
			doAddPhoneWithServiceDiscount(false);
		//	doAddPhoneOnly(false);
			doAddActivationFeeOnly(false);
			$('#iwantservice').val('1')
			});

		$('#phonewiz-3-back').click(function() {
			doResetDlg3();
			// doPhoneWizStart();
			$('#phonewiz-3').dialog("close");
			$('#phonewiz-1').dialog("open");
			return false;
			});
		
		$('#phoneWizDlg_3_International').click(function() {
			doResetDlg3();
			// doPhoneWizInternational()
			$('#phonewiz-3').dialog("close");
			$('#phonewiz-4').dialog("open");
			return false;
			});

		$('#phoneWizDlg_3_addShopBtn').click(function() {
			doResetDlg3();
			doAddPhoneOnly(0);
			$('#phonewiz-3').dialog("close");
			return false;
			});
		
		$('#phoneWizDlg_3_addCheckoutBtn').click(function() {
			doResetDlg3();
			doAddPhoneOnly(1);
			$('#phonewiz-3').dialog("close");
			return false;
			});

		$('#phonewiz-4-back').click(function() {
			// doPhoneWizOtherServicePicker();
			$('#phonewiz-4').dialog("close");
			$('#phonewiz-3').dialog("open");
			return false;
			});

		$('#phoneWizDlg_4_addShopBtn').click(function() {
			doAddPhoneOnly(0);
			$('#phonewiz-4').dialog("close");
			return false;
			});
		
		$('#phoneWizDlg_4_addCheckoutBtn').click(function() {
			doAddPhoneOnly(1);
			$('#phonewiz-4').dialog("close");
			return false;
			});
		
		$('#batwiz-back').click(function() {
			// doPhoneWizOtherServicePicker();
			$('#batwiz').dialog("close");
			return false;
			});

		$('#batwiz_addShopBtn').click(function() {
			$('#batwiz').dialog("close");
			doAddBattery(0);
			return false;
			});
		
		$('#batwiz_addCheckoutBtn').click(function() {
			$('#batwiz').dialog("close");
			doAddBattery(1);
			return false;
			});

		$('#hpwiz-back').click(function() {
			// doPhoneWizOtherServicePicker();
			$('#hpwiz').dialog("close");
			return false;
			});

		$('#hpwiz_addShopBtn').click(function() {
			$('#hpwiz').dialog("close");
			doAddHeadphones(0);
			return false;
			});
		
		$('#hpwiz_addCheckoutBtn').click(function() {
			$('#hpwiz').dialog("close");
			doAddHeadphones(1);
			return false;
			});

		$('#activationPickerContinueButton').click( function() {
			keepGoing = true;
			portNum = "";
			if ($("input[name='activationTypeCtl']:checked").val() == <?= ACTIVATION_FEE_PORT ?>) {
				portNum = $('#portAreaCode').val() + $('#portExchange').val() + $('#portNumber').val();
				if (portNum.length < 10) {
					keepGoing = false;
					alert( "Please enter the phone number you wish to move to your new Snapfon.");
					}
				}
			if (keepGoing) {
				actStr = $("input[name='activationTypeCtl']:checked").val() + "!" + portNum;
				doAddItem( thePlanTheyPicked + "|" + actStr, 1)
				$('#activationpicker').dialog('close');
				$('#addPhoneWithService').hide()
				$('#qty_pws').html("1")
				$('#ezContactPicker').dialog('open')
				}
			});

		$('#ezContactYes').click( function() {
			doAddItem( <?= EZ_CONTACT_SETUP_ID ?>, 1);
			$('#ezContactPicker').dialog( 'close')
			});

		$('#ezContactNo').click( function() {
			$('#ezContactPicker').dialog( 'close')
			});

			$reviewBox = $('#reviewBox').dialog( {
					autoOpen:false,
					closeOnEscape:true,
					modal:true,
					width: 797,
					height:566,
					resizable: false,
					title:false
					});
				
				$coverageChecker = $('#coverageChecker').dialog( {
					autoOpen:false, 
					closeOnEscape:true, 
					modal:true,
					width: 950,
					height:900,
					resizable: false,
					title:false
					})
					
				$('#postYourReview').click( function() {
					$('#reviewBox').dialog("open");
					$('#reviewBox').height("auto");
					});
				$('.ratingStarPicker').click( function() {
					currentID = $(this).attr('id')
					theRating = $(this).attr('rating')
					// Reset the stars
					$('.ratingStarPicker').attr( 'src', "../images/rating-star-outline.png")
					// Set the stars
					for (x=1; x<=theRating; x++) {
						$('#star' + x).attr('src', "../images/rating-star.png")
						}
					$('#custRating').val( theRating);
					});
				$('#goReviewSort').click( function() {
					dojo.xhrPost(
						{
						url: "<?= $mainSitePath ?>/ajax/reviews.php",
						timeout:3000,
						content: {op:"getReviews", sortBy:$('#reviewSort').val()},
						handleAs: "json",
						handle: function(resultData,ioArgs) {
							if (resultData.result == "success") {
								$('#reviewDisplay').html( resultData.newTable);
								}
							else {
								alert(resultData.Message)
								}
							}
						})
					});
				$('#submitReviewButton').click( function() {
					if ($('#custName').val() == "") {
						alert( "Please enter your name.");
						$('#custName').focus();
						return false;
						}
					if ($('#custEMail').val() == "") {
						alert( "Please enter your e-mail address.");
						$('#custEMail').focus();
						return false;
						}
					if ($('#custComments').val() == "") {
						alert( "Please enter your review.");
						$('#custComments').focus();
						return false;
						}
					$('#reviewBox').dialog("close");
					dojo.xhrPost(
						{
						url: "<?= $mainSitePath ?>/ajax/reviews.php",
						timeout:3000,
						content: {
							op:"postReview",
							custName:$('#custName').val(),
							custEMail: $('#custEMail').val(),
							custComments: $('#custComments').val(),
							custRating: $('#custRating').val()
							},
						handleAs: "json",
						handle: function(resultData,ioArgs) {
							if (resultData.result == "success") {
								alert( "Your review has been submitted and will be posted soon! Thanks for your feedback!")
								}
							else {
								alert(resultData.Message)
								}
							}
						})

					});

	
			
});

var cDlg;
var bigPicDlg, sirenDialog, speakingDialog, vidDialog;
killButton = "<img src='/catalog/images/onecall/delete-button-up.png' border='0' ";
killButton += 'onMouseOver="this.src=\'/catalog/images/onecall/delete-button-over.png\'" onMouseOut="this.src=\'/catalog/images/onecall/delete-button-up.png\'" onMouseDown="this.src=\'/catalog/images/onecall/delete-button-down.png\'" onMouseUp="this.src=\'/catalog/images/onecall/delete-button-over.png\'"';
killButton += " />";

function showBigPic( pid, product_name) {
	cContent = "<iframe src='/catalog/product_detail_pages/product_" + pid + ".html' height='525px' width='700px' scrolling='no' frameBorder='0' style='margin:none; padding:none;'>";
	cContent += "</iframe>"
	bigPicDlg = new dijit.Dialog( {
		title:"<div style='float:right;margin-right: 5px;'><a style='color:black;' href='javascript:bigPicDlg.hide()'>" + killButton + "</a></div>&nbsp;&nbsp;",
		style: "width:700px; height:540px; background-color: red !important; border:none;padding:none;margin-left:-5px;",
		content: cContent
		})
	bigPicDlg.show();
	}

function playSiren() {
	cContent = "<iframe src='/catalog/product_detail_pages/sirenSample.html' height='200px' width='500px' scrolling='no' frameBorder='0' style='margin:none; padding:none;'>";
	cContent += "</iframe>"
	sirenDialog = new dijit.Dialog( {
		title:"<div style='float:right;margin-right: 5px;margin-top: 5px;'><a style='color:black;' href='javascript:sirenDialog.hide()'>" + killButton + "</a></div>&nbsp;&nbsp;",
		//style: "width:485px; height:250px; background-color: black !important; border:none;padding:none;",
		content: cContent
		})
	sirenDialog.show();
	}

function playKeyboardSample() {
	cContent = "<iframe src='/catalog/product_detail_pages/speakingSample.html' height='200px' width='500px' scrolling='no' frameBorder='0' style='margin:none; padding:none;'>";
	cContent += "</iframe>"
	speakingDialog = new dijit.Dialog( {
		title:"<div style='background-color:transparent;float:right;margin-right: 5px;margin-top: 5px;'><a style='color:black;' href='javascript:speakingDialog.hide()'>" + killButton + "</a></div>&nbsp;&nbsp;",
		//style: "width:485px; height:250px; background-color: black !important; border:none;padding:none;",
		content: cContent
		})
	speakingDialog.show();
	}

function playSOSVid() {
	$('#vidPlayer').dialog('open');
	}

function onYouTubePlayerReady(playerId) {
	//alert( playerId)
	ytplayer = document.getElementById(playerId);
	//ytplayer.style.paddingTop = "100px"
	ytplayer.playVideo();
	}
				
function doAddItemFromWizard( pid, wizName) {
	$('#' + wizName).dialog('close');
	doAddItem( pid, 1)
	}

function doGetActivationType( pid, wizName) {
	$('#' + wizName).dialog('close');
	$('#activationpicker').dialog('open');
	thePlanTheyPicked = pid;
	}

function doAddOnePhoneWithoutPlan( theID) {
	var oldQty = parseInt( $('#qty_pwos').html(), 10);
	doAddItem( theID, oldQty + 1);
	$('#qty_pwos').html( oldQty + 1);
	}

// This function is for the various "add to cart buttons around the site.
function doAddItem( product_id, quantity) {
				dojo.xhrPost(
					{
					url: "<?= $mainSitePath ?>catalog/ajax/cart_actions_2.php",
					timeout:3000,
					content: {op:"add_item", pid:product_id, qty: quantity},
					handleAs: "json",
					handle: function(resultData,ioArgs) {
						if (resultData.result == "success") {
							if (resultData.newCartData != null) {
								}
							else {
								}
							}
						else {
							alert(resultData.Message)
							}
						}
					})
				}

</script>
		
		
		<script>
		
//product browser functions		
		function switchMain(imgfile)
		{
			var imgpath = '/images/ezonefeatures/main/';
			document.getElementById('imgMain').src = imgpath+imgfile;
		}
		
		function toggleSide(elImg, imgfile)
		{
			var imgpath = '/images/ezonefeatures/side/';
			elImg.src = imgpath+imgfile;
		}
		
		</script>
	
		<script type="text/javascript">
	
			$(document).ready(function() {
				

				});
				
				
function doAddOneMore( ctl, pid) {
	if (pid == <?= HP_DUMM ?>) {
		if (rememberHeadPhoneType == 0) {
			$('#hpwiz').dialog('open');					
			}
		else {
			updateHeadPhoneCounts( rememberHeadPhoneType)
			}
		}
	else if (pid == <?= BATT_DUMM ?>) {
		if (rememberBatteryType == 0) {
			$('#batwiz').dialog('open');					
		}
		else {
			updateBatteryCounts( rememberBatteryType)
			}
		}
	else if (pid == <?= CURRENT_PHONE_ID_WITH_SERVICE ?>) {
		currentPhonePid = pid;
		$('#planpicker').dialog('open');
		}
	else {
		ctl.value = parseInt( ctl.value, 10) + 1
		doAddItem( pid, ctl.value)
		}

	}

	function checkCoverage() {
				$('#coverageChecker').dialog('open');
				}
				
		</script>
    <script type="text/javascript">
        var fb_param = {};
        fb_param.pixel_id = '6006195267217';
        fb_param.value = '0.00';
        (function(){
            var fpw = document.createElement('script');
            fpw.async = true;
            fpw.src = (location.protocol=='http:'?'http':'https')+'://connect.facebook.net/en_US/fp.js';
            var ref = document.getElementsByTagName('script')[0];
            ref.parentNode.insertBefore(fpw, ref);
        })();
    </script>
    <noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/offsite_event.php?id=6006195267217&amp;value=0" /></noscript>
    <style type="text/css">
		.playa { padding-top: 100px;}
    </style>
	</head>
	<body>
	<div id='pageBody'>
		<? include_once( $mainSitePath . 'includes/pageHeader.php'); ?>
		<table cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td id='pageBodyCell'>
					
					<!-- START Snapfon ezONE TABLE -->
					<table width="100%">
					
					<tr>
						<td width="386">
						<!-- Phone Details pic browser -->
						
							<table cellpadding="0" cellspacing="0">
								<tr>
									<td valign="top">
										<img id="imgMain" src="/images/ezonefeatures/main/ez-one-main-starting-shot.jpg"alt="Snapfon ezONE the cell phone for seniors main view">
									</td>
								
									<td valign="top">
											<!-- Detailed Side rollovers -->
										<table cellpadding="0" cellspacing="0" style="border-spacing: 0px;">
											<tr>
												<td valign='middle'>
													<img style='margin-bottom: 0px;' src="/images/ezonefeatures/side/back.jpg" alt="Snapfon ezONE the cell phone for seniors rear view"
														onmouseover="toggleSide(this,'back-over.jpg');switchMain('ez-one-sos-emergency-alert-button.jpg');"
														onmouseout="toggleSide(this,'back.jpg');"
														onmousedown="toggleSide(this,'back-over.jpg');switchMain('ez-one-sos-emergency-alert-button.jpg');">
													<img style='margin-top:-3px; margin-bottom: 0px;' src="/images/ezonefeatures/side/front.jpg"alt="Snapfon ezONE the cell phone for seniors front view"
														onmouseover="toggleSide(this,'front-over.jpg');switchMain('ez-one-large-easy-to-read-screen.jpg');"
														onmouseout="toggleSide(this,'front.jpg');"
														onmousedown="toggleSide(this,'front-over.jpg');switchMain('ez-one-large-easy-to-read-screen.jpg');">
													<img style='margin-top:-3px; margin-bottom: 0px;' src="/images/ezonefeatures/side/top.jpg"alt="Snapfon ezONE the senior cell phone top view"
														onmouseover="toggleSide(this,'top-over.jpg');switchMain('ez-one-top-details.jpg');"
														onmouseout="toggleSide(this,'top.jpg');"
														onmousedown="toggleSide(this,'top-over.jpg');switchMain('ez-one-top-details.jpg');">
													<img style='margin-top:-3px; margin-bottom: 0px;' src="/images/ezonefeatures/side/left.jpg"alt="Snapfon ezONE the senior cell phone left view"
														onmouseover="toggleSide(this,'left-over.jpg');switchMain('ez-one-volume-control.jpg');"
														onmouseout="toggleSide(this,'left.jpg');"
														onmousedown="toggleSide(this,'left-over.jpg');switchMain('ez-one-volume-control.jpg');">
													<img style='margin-top:-3px; margin-bottom: 0px;' src="/images/ezonefeatures/side/right.jpg" alt="Snapfon ezONE the senior cell phone right view"
														onmouseover="toggleSide(this,'right-over.jpg');switchMain('ez-one-right-details.jpg');"
														onmouseout="toggleSide(this,'right.jpg');"
														onmousedown="toggleSide(this,'right-over.jpg');switchMain('ez-one-right-details.jpg');">
													<img style='margin-top:-3px; margin-bottom: 0px;' src="/images/ezonefeatures/side/bottom.jpg"alt="Snapfon ezONE the senior cell phone bottom view"
														onmouseover="toggleSide(this,'bottom-over.jpg');switchMain('ez-one-bottom-details.jpg');"
														onmouseout="toggleSide(this,'bottom.jpg');"
														onmousedown="toggleSide(this,'bottom-over.jpg');switchMain('ez-one-bottom-details.jpg');">
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
						</td>
						
						<td align="center" valign="top">
						
							<table>
								<tr><td align="center"><span class="bigOlText">Snapf&#333;n <span class="ezOrange">ez</span>ONE</span></td></tr>
								<tr><td align="center"><h1>Big numbers and buttons with built in SOS make this phone the best choice for seniors.</h1><br></td></tr>
								
								<tr><td valign="top" align="center">
									<table align="center">
									<tr>
										<td align="center" width="200" valign="top">
											<span class="ezGreen bigOlText">$<?= PRICE_WITH_PLAN ?></span><br>
											with any service plan<br> starting at<br>
											only $14.95 a month<br>
											<br><br>
											<span class="ezGreen">*one-time $<?= ACTIVATION_FEE_AMOUNT ?> activation fee required</span><br><br>
											<? if (!$cart->in_cart( CURRENT_PHONE_ID_WITH_SERVICE)) { ?>
												<img id='addPhoneWithService' align="top" style='cursor:pointer; margin-top:-2px;'
													src='../catalog/images/refresh_2012/add-to-cart-button.png'alt="Snapfon add to cart button"
													onClick="doAddOneMore( document.ohsnap.qty_2, <?= CURRENT_PHONE_ID_WITH_SERVICE ?>)"
													onMouseOver="this.src='../catalog/images/refresh_2012/add-to-cart-button_over.png'"
													onMouseOut="this.src='../catalog/images/refresh_2012/add-to-cart-button.png'"
													onMouseDown="this.src='../catalog/images/refresh_2012/add-to-cart-button_click.png'"
													onMouseUp="this.src='../catalog/images/refresh_2012/add-to-cart-button_over.png'" />
											<? } ?>
											<br><br>
											<span id='limitPhonesWithService' class='' style="font-size:12pt;;">Limit 1 per order.<br></span>
											Quantity: <span class='smallText' id="qty_pws"><?= $cart->get_quantity( CURRENT_PHONE_ID_WITH_SERVICE) ?></span>

										</td>
										<!-- td align="center" width="30" valign="top"><img src="/images/ezonefeatures/your-choice.jpg" alt="Snapfon ezONE senior lifestyle cellphone your choice icon" border="0" /></td>
										<td align="center" width="200" valign="top">
											<span class="ezGreen bigOlText">$<?= PRICE_WITHOUT_PLAN ?></span><br>
											unlocked ezONE for use<br>
											with service of your<br>
											choice*<br>
											<br><br>
											<span class="ezGreen">*Works with AT&T, T-Mobile and more</span><br><br>
											
											<img id='addPhoneWithOutService' align="top" style='cursor:pointer; margin-top:-2px;display:<?= (($numPWS == 0) ? "inline" : "none") ?>;' 															src='../catalog/images/refresh_2012/add-to-cart-button.png'
												onClick="doAddOnePhoneWithoutPlan( <?= CURRENT_PHONE_ID ?>)"
												onMouseOver="this.src='../catalog/images/refresh_2012/add-to-cart-button_over.png'"
												onMouseOut="this.src='../catalog/images/refresh_2012/add-to-cart-button.png'"
												onMouseDown="this.src='../catalog/images/refresh_2012/add-to-cart-button_click.png'"
												onMouseUp="this.src='../catalog/images/refresh_2012/add-to-cart-button_over.png'" />
											<br/>
											<br/>
											Quantity: <span class='smallText' id="qty_pwos"><?= $cart->get_quantity( CURRENT_PHONE_ID) ?></span>

										</td -->
									</tr>
									
									
									</table>
								
								
								</td></tr>

                                <tr><td align="center"><span class="biggishText ezGreen"><br>IN STOCK  ships in 2-3 business days</span></td></tr>
                                <tr><td align="center"><span class="biggishText ezGreen">Get it faster by choosing Rush Processing during checkout!</span></td></tr>
							</table>
						
						
						
						
						</td>
					</tr>
					<tr>
						<td colspan="2">
							
							<table width="960">
								<tr>
									<td width="710">
									
									<script>
										
										function displayContent(selected_tab_name)
										{
											var tab_names = Array('details', 'specs', 'accessories', 'reviews');
										
											for(i=0;i<tab_names.length;i++)
											{
												if(tab_names[i] == selected_tab_name)
												{
													document.getElementById('div_tabcontent_'+tab_names[i]).style.display = 'block';
													document.getElementById('div_tab_'+tab_names[i]).className = 'activeTab';
												
												} else {
												
													document.getElementById('div_tabcontent_'+tab_names[i]).style.display = 'none';
													document.getElementById('div_tab_'+tab_names[i]).className = 'inactiveTab';
												}
											
											
											}
										}
										
									</script>
										<table width="710">
											<tr>
												<td width="100"><div id="div_tab_details" onclick="displayContent('details');" class="activeTab">Details</div></td>
												<td width="100"><div id="div_tab_specs" onclick="displayContent('specs');" class="inactiveTab">Specs</div></td>
												<td width="100"><div id="div_tab_accessories" onclick="displayContent('accessories');" class="inactiveTab">Accessories</div></td>
												<td width="100"><div id="div_tab_reviews" onclick="displayContent('reviews');" class="inactiveTab">Reviews</div></td>
												<td width="310">&nbsp;</td>
											</tr>
											<tr>
												<td colspan="5">
													<div id="div_tabcontent_details" class="tabContentPane">
													
														<table cellspacing="20">
															<tr>
																<td width="230" valign="top">
																	<span class="ezGreen bigText">Easy-to-Use features:</span>
																	<br>
																	<ul class="accentColorList">
																		<li><span>Big Buttons</span></li>
																		<li><span>Easy to read screen</span></li>
																		<li><span>Enhanced volume</span></li>
																		<li><span>High power LED flashlight</span></li>
																		<li><span>Speaking keypad</span></li>
																		<li><span>8 Speed Dial Keys <span class="ezGreen">-ezContact setup available</span></span></li>
																		<li><span>Extra long battery life</span></li>
																		<li><span>Quad-band world phone<br>
																			(GSM 850/900/1800/1900 Mhz)</span></li>
																		
																	</ul>
																	
																	<a href="/ez-one-support/tech_specs.php">
																		<img src="/images/ezonefeatures/buttons/more-details-up.png" alt="Snapfon offering PERS more details button"
																		border="0" 
																		
																		style="margin-left:28px;">
																	</a>
																
																</td>
																<td valign="top">
																
																	<span class="ezGreen bigText">SOS Emergency Alert:</span>
																	<br>
																	<ul class="accentColorList">
																		<li><span>Press and hold for 5 seconds to alert up to 4 responders by voice and text message</span></li>
																		<li><span>Loud 120 db siren can alert those close-by to emergency (can be switched off in menu)</span></li>
																		<li><span>Automatically switches to speaker phone mode for emergency calls</span></li>
																		<li>NOW <span>available with</span> <a href="/services/onecall_mobile.php">oneCall Mobile!</a></li>
																	</ul>
																</td>
																<td>
																	<img src="/images/ezonefeatures/ez-one-sos-button-back.png" alt="SOS emergency alert feature" border="0"><br><br>
																	<img style='cursor:pointer;margin-bottom:5px;'
																		src='../catalog/images/refresh_2012/play-sos-siren-up.png'alt="play example SOS siren for emergency alert feature"
																		onClick="playSiren()"
																		onMouseOver="this.src='../catalog/images/refresh_2012/play-sos-siren-over.png'"
																		onMouseOut="this.src='../catalog/images/refresh_2012/play-sos-siren-up.png'"
																		onMouseDown="this.src='../catalog/images/refresh_2012/play-sos-siren-click.png'"
																		onMouseUp="this.src='../catalog/images/refresh_2012/play-sos-siren-over.png'" />

																	<img style='cursor:pointer;'
																		src='../catalog/images/refresh_2012/play-speaking-keypad-up.png'alt="play example speaking keypad feature"
																		onClick="playKeyboardSample()"
																		onMouseOver="this.src='../catalog/images/refresh_2012/play-speaking-keypad-over.png'"
																		onMouseOut="this.src='../catalog/images/refresh_2012/play-speaking-keypad-up.png'"
																		onMouseDown="this.src='../catalog/images/refresh_2012/play-speaking-keypad-click.png'"
																		onMouseUp="this.src='../catalog/images/refresh_2012/play-speaking-keypad-over.png'" />
																	<img style='cursor:pointer;'
																		src='../catalog/images/refresh_2012/play-video-button.png'alt="play example video featuring oneCall Mobile personal urgent response system"
																		onClick="playSOSVid()"
																		onMouseOver="this.src='../catalog/images/refresh_2012/play-video-button_over.png'"
																		onMouseOut="this.src='../catalog/images/refresh_2012/play-video-button.png'"
																		onMouseDown="this.src='../catalog/images/refresh_2012/play-video-button_click.png'"
																		onMouseUp="this.src='../catalog/images/refresh_2012/play-video-button_over.png'" />
																</td>
															</tr>
															<tr>
																<td colspan="3">
																	<table>
																		<tr>
																			<td width="170">
																				<span class="ezGreen bigText">What's In The Box</span><br>
																				<img src="/images/ezonefeatures/snapfon-box.png" alt="senior cellphone box" border="0">
																			</td>
																			<td width="240">
																				<ul class="accentColorList">
																					<li><span>One Snapf&#333;n&reg; ezONE cell phone</span></li>
																					<li><span>One wall charger</span></li>
																					<li><span>One battery</span></li>
																					<li><span>One Snapf&#333;n&reg; ezONE user guide</span></li>
																				</ul>	
																			</td>
																			<td>
																				<img src="/images/ezonefeatures/ez-one-package-contents.png" alt="ezONE package contents" border="0">
																			</td>
																		</tr>
																	</table>
																
																</td>
															</tr>
														
														</table>
													</div> <!-- div_tabcontent_details -->
													
													<div id="div_tabcontent_specs" style="display:none" class="tabContentPane">
													
														<table width="100%" border="0">
															<tr>
																<td width="50%" valign="top" align="left">
																	<div style="margin: 20px;">	
																	<span class="ezGreen" style="text-decoration:underline;font-weight:bold;">Senior Features</span>
																	<dl>
  																		<dt>Speaking Keypad</dt>
    																		<dd><i>(Announces numbers clearly when dialing)</i></dd>
  																		<dt>Keypad Lock</dt><dd>&nbsp;</dd>
  																		<dt>Bright LED Flashlight</dt><dd>&nbsp;</dd>
  																		<dt>Large menu scroll Key:&nbsp;</dt><dd>16mm x 15mm</dd>
   																		<dt>Large Number Keys:&nbsp;</dt><dd>16mm x 9mm</dd>
   																		<dt>Large Font When Dialing:&nbsp;</dt><dd>28 point</dd>
   																		<dt>Loud Receiver Volume:&nbsp;</dt><dd>107 dB</dd>
   																		<dt>Amplification:&nbsp;</dt><dd>22 Decibels</dd>
   																		<dt>Lanyard Connection</dt><dd>&nbsp;</dd>
                                                                        <dt>Built-in Camera</dt>
                                                                        <dt>Bluetooth enabled</dt>
                                                                        <dt>4 Alarm Modes</dt>
                                                                        <dt>Vibrating Alert</dt>
																	</dl> 
																	</div>
																	
																	<div style="margin: 20px;">															
																	<span class="ezGreen" style="text-decoration:underline;font-weight:bold;">SOS Emergency Button</span>
																	<dl>
  																		<dt>Can Be Activated or Deactivated</dt><dd>&nbsp;</dd>
  																		<dt>Optional Siren When Activated</dt><dd>&nbsp;</dd>
  																		<dt>Calls and Sends an SMS to up to 5 Programmable Emergency Numbers</dt><dd>&nbsp;</dd>
  																		<dt>Connects to Emergency Contact with Speakerphone</dt><dd>&nbsp;</dd>
  																		<dt>English and Spanish Menus</dt><dd>&nbsp;</dd>
  																	</dl>
																	</div>
																	
																		
																	<div style="margin: 20px;">															
																	<span class="ezGreen" style="text-decoration:underline;font-weight:bold;">Power</span>
																	<dl>
  																		<dt>Talk Time:&nbsp;</dt><dd>3-4 hours</dd>
  																		<dt>Standby Time:&nbsp;</dt><dd>90-120 hours</dd>
  																		<dt>Lithium-ion Battery:&nbsp;</dt><dd>Li-ion 3.7V/1000mAh</dd>
  																		<dt>Snapfon Charger Input:&nbsp;</dt><dd>Micro USB 100-240VAC-50/60hz, .3A MAX</dd>
  																		<dt>Snapfon Charger Output:&nbsp;</dt><dd>5.5 VDC/500mA</dd>
																	</div>
																
																</td>
																<td width="50%" valign="top" align="left">
																	
																	<div style="margin: 20px;">	
																	<span class="ezGreen" style="text-decoration:underline;font-weight:bold;">Call Features</span>
																	<dl>
  																		<dt>One Touch Voicemail Dialing</dt><dd>&nbsp;</dd>
    																	<dt>200 Phonebook Contacts</dt><dd>&nbsp;</dd>
  																		<dt>8 Speed Dial Locations</dt><dd>&nbsp;</dd>
  																		<dt>Handsfree Speakerphone</dt><dd>&nbsp;</dd>
  																		<dt>Call Hold</dt><dd>&nbsp;</dd>
  																		<dt>Side Volume Rocker key</dt><dd>&nbsp;</dd>
  																		<dt>Call Timer</dt><dd>&nbsp;</dd>
  																		<dt>Time and Date</dt><dd>&nbsp;</dd>
  																		<dt>9 Polyphonic Ringtones</dt><dd>&nbsp;</dd>
  																		<dt>Vibrating Alert</dt><dd>&nbsp;</dd>
  																		<dt>Silent Mode</dt><dd>&nbsp;</dd>
  																		<dt>Logs 10 Recent:&nbsp;</dt><dd>Dialed, Received and Missed Calls</dd>
  																		<dt>Headset Connection 3.5 mm</dt><dd>&nbsp;</dd>
																	</dl> 
																	</div>
																	
																	
																	<div style="margin: 20px;">	
																	<span class="ezGreen" style="text-decoration:underline;font-weight:bold;">Messaging</span>
																	<dl>
  																		<dt>SMS Ringtones:&nbsp;</dt><dd>6 polyphonic</dd>
  																		<dt>Storage&nbsp;</dt><dd>200 Messages</dd>
																	</dl> 
																	</div>
																	
																			
																	<div style="margin: 20px;">	
																	<span class="ezGreen" style="text-decoration:underline;font-weight:bold;">Technical</span>
																	<dl>
  																		<dt>Form&nbsp;</dt><dd>Bar</dd>
  																		<dt>Color:&nbsp;</dt><dd>Dark Grey Metallic Body - Silver Bezel</dd>
  																		<dt>Size H x W x D:&nbsp;</dt><dd>118.5 x 57.5 x 15.3mm</dd>
  																		<dt>Screen:&nbsp;</dt><dd>46 x 36mm</dd>
    																	<dt>Weight:&nbsp;</dt><dd>2.3 oz<i>(with battery)</i></dd>
    																	<dt>Antenna:&nbsp;</dt><dd>Internal</dd>
																	</dl> 
																	</div>
																	
																	
																</td>
															</tr>
														</table>
														
													</div> <!-- div_tabcontent_specs -->
													
													<div id="div_tabcontent_accessories" style="display:none;overflow:auto;" class="tabContentPane">
													
													
													
													<div id='productsTable'>
													<div style="text-align: center;">
														<span class='ezGreen'>For batteries and headphones, please visit our main <a href='/catalog/index.php' class="ezGreen">Store</a> page.</span>
													</div>
													<hr/>
        <?php echo tep_draw_form('ohsnap', tep_href_link('index.php', 'action=snap_add_products')); ?>
        <table border="0" width="100%" cellspacing="0" cellpadding="0">
    	<?
		$item = 1;
        	if ($category_id == SHOW_ACCESSORIES_ID) {
        		$allCategoriesWeCareAbout = "28, 29, 30";
        		}
        	$cond = " and p.dealer_only = 0 ";
        	$theOrder = "asc";
			if (tep_session_is_registered('customer_id')) {
				if ($is_dealer) {
					$cond = "";
					$theOrder = "desc";
					}
				else {
					}
				}
     
     		$headsets = HP_A . ", " . HP_B . ", " . HP_C;
     		$batteries = BATT_A . ", " . BATT_B . ", " . BATT_C;
			$collapseFilter = " and (p.products_id not in ($headsets, $batteries)) ";
			$catCond = "";
			if (($category_id == -1) || ($category_id == SHOW_ACCESSORIES_ID)) {
				$catCond .= " and ptc.categories_id in ( $allCategoriesWeCareAbout) ";
				}
			else {
				$catCond .= " and ptc.categories_id = $category_id ";
				}

			$query = "SELECT DISTINCT p.*, pd.*, ptc.categories_id, cd.categories_name FROM products p, products_description pd, products_to_categories ptc, categories_description cd WHERE p.products_id = pd.products_id AND p.products_status=1 AND pd.language_id=1 and (p.products_price > 0) and p.products_id=ptc.products_id $cond $catCond $collapseFilter and ptc.categories_id=cd.categories_id and cd.language_id=1 ORDER BY categories_id, products_sort_order $theOrder";
			
			
			$pres = tep_db_query( $query);
			$productCount = mysql_num_rows( $pres);
			if ($category_id == SHOW_ALL_ID) $productCount++; // throw the phone in there
			$rc = 'odd';
			$isAccessory = false;
			$accessoryCount = 0;
			$thisCategoryID = 0;
			$lastCategoryID = -1;
			$cellCount = 1;
			$rowLimit = 2;
			$rowIsOpen = false;
//			echo($query);
			while ($pinfo = mysql_fetch_assoc( $pres)) { 
				$thisCategoryID = $pinfo['categories_id'];
				if ($thisCategoryID != $lastCategoryID) {
					$lastCategoryID = $thisCategoryID;
					$cellCount = 1;
					if ($rowIsOpen) {
						echo("</tr>");
						}
					?>
					<tr class="categoryHeading">
						<td colspan="3" class="biggerText ezGreen" align="center">
							<?= $pinfo['categories_name'] ?>
						</td>
					</tr>		
				<?	}
				// These are hidden. Merged into one virtual item
				if ($pinfo['products_id'] == HP_DUMM || $pinfo['products_id'] == HP_B || $pinfo['products_id'] == HP_A || $pinfo['products_id'] == BATT_DUMM || $pinfo['products_id'] == BATT_A || $pinfo['products_id'] == BATT_B || $pinfo['products_id'] == 48 || $pinfo['products_id'] == 49 || $pinfo['products_id'] == 50 || $pinfo['products_id'] == 51 || $pinfo['products_id'] == 56) {
					//echo "skipping";
					continue;
					}
				if ($pinfo['products_sort_order'] >= 9000) {
					$accessoryCount++;
					$isAccessory = true;
					}
				else {
					$isAccessory = false;
					}
				if ($cellCount == 0) { 
					$rowIsOpen = true;
					?>
					<tr class="productListing-<?= $rc ?>" style='<?= (($isAccessory) ? "display:table-row" : "") ?>' <?= (($isAccessory) ? "id='accRow_" . $accessoryCount . "'" : '') ?>>
				<? } ?>
				
					<td class="productListing-data shopCell" width="50%" valign="top">
						<table>
							<tr>
								<td valign="top">
									<div class='smallText' id='<?= $pinfo['products_model'] ?>'><? ?>
									<? 
									$bigImage = false;
									if (file_exists("/var/www/snapfon2012/catalog/product_detail_pages/product_" . $pinfo['products_id'] . ".html")) {
										$bigImage = true;
										//echo "<a href='product_detail_pages/product_". $pinfo['products_id'] . ".html' target='bigun'>";
										echo "<a href='javascript:showBigPic(". $pinfo['products_id'] . ", " . '"' . $pinfo['products_name'] . '"' . ")'>";
										}
									?>
									<?= tep_image( "/catalog/images/" . $pinfo['products_image'], '', '100', '', 'align=left') ?>
									<? if ($bigImage) { 
										echo "</a>";
										} ?>
									</div>
								</td>
								<td valign="top">
									<div style="" class=""><span class="ezGreen bigText"><?= $pinfo['products_name'] ?></span><br><?= $pinfo['products_description'] ?></div>
									<br><br>
									<div class='smallText' id='<?= $pinfo['products_model'] ?>_price'>
										<span class='bigText'>Price: <span class='ezGreen'>$<?= number_format( $pinfo['products_price'], 2) ?></span></span>
										<? if ($pinfo['products_id'] == 44) { ?>
											<br><br>
								    		<span class='required callToAction bigger'>$69.99 with mail-in rebate! 50 free minutes with a Flex plan activation!<br><span style="font-size:12px;"><a href='../plans/compare-rates.php#bonus'>(Details on Plans page.)</a></span></span>
										<? } ?>
										<? if ($pinfo['products_id'] == 58) { ?>
											<br><br>
								    		<span class='required callToAction bigger'>50 free minutes with a Flex plan activation!<br><span style="font-size:12px;"><a href='../plans/compare-rates.php#bonus'>(Details on Plans page.)</a></span></span>
										<? } ?>
										<? if ($pinfo['products_id'] == 64) { ?>
											<br>
								    		<span class='required callToAction bigger'>$69.99 with mail-in rebate! 50 free minutes with a Flex plan activation!<br><span style="font-size:12px;"><a class="accentColor" href='../plans/compare-rates.php#bonus'>(Details on Plans page.)</a></span></span>
										<? } ?>
										
										
										<? if ($pinfo['products_id'] == 54) { ?>
											<br><br>
											<span class='required callToAction bigger'>20% discount on one keyboard with <br>Snapfon purchase!<br><br>Or, purchase a Keyboard + Mouse Combo for just $47.95!</span>
										<? } ?>
										<? if ($pinfo['products_id'] == 55) { ?>
											<br><br>
											<span class='required callToAction bigger'>20% discount on one mouse with <br>Snapfon purchase!<br><br>Or, purchase a Keyboard + Mouse Combo for just $47.95!</span>
										<? } ?>
										<? if ($pinfo['products_id'] == 57) { ?>
											<br>
											<span class='required callToAction bigger'>Also available as a FREE download!<br><span style="font-size:12px;"><a class='accentColor' href='../ez-one-support/default.php#downloads'>(Download from Support Page.)</a></span></span>
										<? } ?>
									</div>
									<div class='smallText' id='<?= $pinfo['products_model'] ?>_qty'>
									<img style='cursor:pointer;' src='/catalog/images/refresh_2012/add-to-cart-button.png' 
										onClick="doAddOneMore(document.ohsnap.qty_<?= $item ?>, <?= $pinfo['products_id'] ?>)" 
										onMouseOver="this.src='/catalog/images/refresh_2012/add-to-cart-button_over.png'" 
										onMouseOut="this.src='/catalog/images/refresh_2012/add-to-cart-button.png'" 
										onMouseDown="this.src='/catalog/images/refresh_2012/add-to-cart-button_click.png'"
										 onMouseUp="this.src='/catalog/images/refresh_2012/add-to-cart-button_over.png'" /><br>
									Quantity: <input class='smallText ' type='text' name='qty_<?= $item ?>' size='4' maxlength='4' value='<?= $cart->get_quantity( $pinfo['products_id']) ?>' readonly style='border:none;text-align:right;'>
									</div>
									<input type="hidden" name='qty_id_<?= $pinfo['products_id'] ?>' value="<?= $item ?>" />
									<input type='hidden' name='pid_<?= $item++ ?>' value='<?= $pinfo['products_id'] ?>'>
								</td>
							</tr>
						</table>
					</td>
				<? if ($cellCount == 1) { ?>
					<td>
						<table border="0" height="180px">
							<tr>
							<td class="divCell"><img src="../catalog/images/pixel_trans.gif" border="0" alt="" width="100%" height="1"></td>	
							</tr>
						</table>
					</td>
				<? }	
				if ($cellCount >= $rowLimit) { 
					$cellCount = 1;
					$rowIsOpen = false;
					?>
					</tr>				
				<? } else {
					$cellCount++;
					}
				if ($rc == 'odd') {
					$rc = 'even';
					}
				else {
					$rc = 'odd';
					}
				} 
			if ($rowIsOpen) echo "</tr>";
			?>
			<!-- Type A Headset -->
			<input type="hidden" name='qty_id_<?= HP_A ?>' value="<?= $item ?>" />
			<input type='hidden' name='pid_<?= $item ?>' value='<?= HP_A ?>' >
			<input type='hidden' name='qty_<?= $item++ ?>' value='<?= $cart->get_quantity( HP_A) ?>' >

			<!-- Type B Headset -->
			<input type="hidden" name='qty_id_<?= HP_B ?>' value="<?= $item ?>" />
			<input type='hidden' name='pid_<?= $item ?>' value='<?= HP_B ?>' >
			<input type='hidden' name='qty_<?= $item++ ?>' value='<?= $cart->get_quantity( HP_B) ?>' >
			
			<!-- Type C Headset -->
			<input type="hidden" name='qty_id_<?= HP_C ?>' value="<?= $item ?>" />
			<input type='hidden' name='pid_<?= $item ?>' value='<?= HP_C ?>' >
			<input type='hidden' name='qty_<?= $item++ ?>' value='<?= $cart->get_quantity( HP_C) ?>' >

			<!-- Type A Battery -->
			<input type="hidden" name='qty_id_<?= BATT_A ?>' value="<?= $item ?>" />
			<input type='hidden' name='pid_<?= $item ?>' value='<?= BATT_A ?>' >
			<input type='hidden' name='qty_<?= $item++ ?>' value='<?= $cart->get_quantity( BATT_A) ?>' >
			
			<!-- Type B Battery -->
			<input type="hidden" name='qty_id_<?= BATT_B ?>' value="<?= $item ?>" />
			<input type='hidden' name='pid_<?= $item ?>' value='<?= BATT_B ?>' >
			<input type='hidden' name='qty_<?= $item++ ?>' value='<?= $cart->get_quantity( BATT_B) ?>' >
			
			<!-- Type C Battery -->
			<input type="hidden" name='qty_id_<?= BATT_C ?>' value="<?= $item ?>" />
			<input type='hidden' name='pid_<?= $item ?>' value='<?= BATT_C ?>' >
			<input type='hidden' name='qty_<?= $item++ ?>' value='<?= $cart->get_quantity( BATT_C) ?>' >
			
			<!-- SIMS. Probably not used... -->
			<input type="hidden" name='qty_id_48' value="<?= $item ?>" />
			<input type='hidden' name='pid_<?= $item ?>' value='48' >
			<input type='hidden' name='qty_<?= $item++ ?>' value='<?= $cart->get_quantity( 48) ?>' >
			
			<input type="hidden" name='qty_id_49' value="<?= $item ?>" />
			<input type='hidden' name='pid_<?= $item ?>' value='49' >
			<input type='hidden' name='qty_<?= $item++ ?>' value='<?= $cart->get_quantity( 49) ?>' >
			
			<input type="hidden" name='qty_id_50' value="<?= $item ?>" />
			<input type='hidden' name='pid_<?= $item ?>' value='50' >
			<input type='hidden' name='qty_<?= $item++ ?>' value='<?= $cart->get_quantity( 50) ?>' >
			
			<input type="hidden" name='qty_id_51' value="<?= $item ?>" />
			<input type='hidden' name='pid_<?= $item ?>' value='51' >
			<input type='hidden' name='qty_<?= $item++ ?>' value='<?= $cart->get_quantity( 51) ?>' >
			
			<input type="hidden" name='qty_id_56' value="<?= $item ?>" />
			<input type='hidden' name='pid_<?= $item ?>' value='56' >
			<input type='hidden' name='qty_<?= $item++ ?>' value='<?= $cart->get_quantity( 56) ?>' >
        </table>
        <br>
		<!--input type="image" style="float:right; margin-right:7px;" style='cursor:pointer;'
			src='/catalog/images/refresh_2012/checkout-button.png' 
			onclick="document.forms['ohsnap'].submit()" 
			onmouseover="this.src='/catalog/images/refresh_2012/checkout-button_over.png'" 
			onmouseout="this.src='/catalog/images/refresh_2012/checkout-button.png'" 
			onmousedown="this.src='/catalog/images/refresh_2012/checkout-button_click.png'" 
			onmouseup="this.src='/catalog/images/refresh_2012/checkout-button_over.png'" /><br-->
        <input type='hidden' name='productCount' value="<?= $item-1 ?>" />
		</form>
        </div>
        													
													
													</div> <!-- div_tabcontent_accessories -->
													
													<div id="div_tabcontent_reviews" style="display:none;overflow:auto;" class="tabContentPane">
													
													
													
													<img id='postYourReview' style='cursor:pointer; float:right;' 
														src='/images/ezonefeatures/buttons/post-your-review-up.png' alt="post your review on snapfon ezONE with oneCall Mobile Urgent Personal Emergency Response System"
														onMouseOver="this.src='/images/ezonefeatures/buttons/post-your-review-over.png'" 
														onMouseOut="this.src='/images/ezonefeatures/buttons/post-your-review-up.png'" 
														onMouseDown="this.src='/images/ezonefeatures/buttons/post-your-review-down.png'" 
														onMouseUp="this.src='/images/ezonefeatures/buttons/post-your-review-over.png'" />
													
													<div id='reviewDisplay' style="margin-left:19px; margin-right:19px; margin-bottom:16px;">
														<table border="0" width="100%">
														<?
														$query = "select * from reviews r, reviews_description rd where r.products_id=28 and r.approved=1 and r.reviews_id=rd.reviews_id order by date_added desc limit 4";
														$cRes = mysql_query( $query, $qCon);
														$numRevs = mysql_num_rows( $cRes);
														if ($numRevs == 0) {
															?>
															<tr>
																<td>&nbsp;</td>
															</tr>
															<tr>
																<td>
																No testimonials are currently available. Please try again later.
																</td>
															</tr>
															<?
															}
														else {
															while ($cInfo = mysql_fetch_assoc( $cRes)) {
																?>
																<tr>
																	<td>&nbsp;</td>
																</tr>
																<tr>
																	<td class="grayText">
																	<? for ($x=1; $x<= $cInfo['reviews_rating']; $x++) { ?>
																		<img class='ratingStar' src="../images/rating-star.png" width="20" height="20">
																	<? } ?>
																	&nbsp;by&nbsp;
																	<span class='snapName snugBottom'><?= $cInfo['customers_name'] ?></span>
																	&nbsp;<?= date( "m/d/Y", strtotime( $cInfo['date_added'])) ?>
																	<br>
																	<?= $cInfo['reviews_text'] ?>
																	</td>
																</tr>
														
																<?
																}
															}
														mysql_free_result( $cRes);
														?>
														</table>
													</div> <!-- reviewDisplay -->

												
													
													<span styler="margin:20px;"><a href="/customer-testimonials/">Click to view more reviews</a></span><br><br><br>
												</div><!-- div_tabcontent_reviews -->
													
												</td>
											</tr>
									
										</table>
							
									</td>
									<td width="210" align="center" valign="top">
										<div class='hiddenBit'>
											<span class="ezGreen bigText" onclick="javascript:checkCoverage()">Dependable Coverage</span><br>
											<a href="javascript:checkCoverage()">
												<img src="/images/ezonefeatures/coverage-map.png" alt="Coverage map" width="210" alt="" border="0" />
											</a>


											<p style="text-align:left;">
											Our service is provided by
											the nation's most reliable
											and trusted GSM networks<br>
											View Our Coverage Map
											</p>
											<span class="ezGreen biggishText">We're Here to Help!</span><br>
											View our <a href="/ez-one-support/">Support</a> page or
											Contact Us Monday to Friday from 9-7 (Eastern Standard Time)
										</div>
                                        <a href="/services/ezcontact_setup.php"><img src="/images/limited_time/limited-time-offer-free-handsfree-headset.png" alt="Limited Time offer! Free Handsfree headset" border="0" style="margin-top:30px;" /><br/><br/>
										<img src="/images/limited_time/limited-time-offer-free-shipping.png" alt="Limited Time offer! Free usps Priority Shipping" border="0" />
									</td>
								</tr>
							</table>
						
						</td>
					</tr>
					
					</table>
					<!-- END Snapfon ezONE TABLE -->
					
					
					
					
					
					
				</td>
			</tr>
		</table>
		
		<? include_once( $mainSitePath . 'includes/pageFooter.php'); ?>
	</div>
	
	
	
<div id="reviewBox" title="" style="display:none;background-image:url(/catalog/images/wizards/whatsinthebox/whats-in-the-box-lightbox-back.png);background-repeat:no-repeat;">
		<fieldset>
			<div id='reviewBoxContent'>
			<center>
				<table cellpadding="0" cellspacing="0" border="0" width="85%">
					<tr>
						<td>
							<form name="ctForm" action='process-testimonial.php' method="post">
								<table border="0">
									<tr>
										<td colspan="1">Name:</td>
										<td colspan="1"><input type="text" name="custName" id='custName' size="30"></td>
									</tr>
									<tr>
										<td colspan="1">E-Mail Address:</td>
										<td colspan="1"><input type="text" name="custEMail" id='custEMail' size="30"></td>
									</tr>
									<tr>
										<td colspan="1">Your Rating:</td>
										<td colspan="1">
											<img class='ratingStarPicker' id='star1' rating='1' src="../images/rating-star.png" height="20" width="20" />
											<img class='ratingStarPicker' id='star2' rating='2' src="../images/rating-star.png" height="20" width="20" />
											<img class='ratingStarPicker' id='star3' rating='3' src="../images/rating-star.png" height="20" width="20" />
											<img class='ratingStarPicker' id='star4' rating='4' src="../images/rating-star.png" height="20" width="20" />
											<img class='ratingStarPicker' id='star5' rating='5' src="../images/rating-star.png" height="20" width="20" />
											<input type="hidden" name="custRating" id='custRating' value='5' />
										</td>
									</tr>
									<tr>
										<td colspan="2">Your Review:</td>
									</tr>
									<tr>
										<td colspan="2"><textarea name="custComments" id='custComments' rows="10" cols="80"></textarea></td>
									</tr>
									<tr>
										<td colspan="2">
											<img id='submitReviewButton' 
											style='cursor:pointer; float:right;' 
											src='../images/reviews/submit-button.png' alt="submit button"
											onMouseOver="this.src='../images/reviews/submit-button_over.png'" 
											onMouseOut="this.src='../images/reviews/submit-button.png'" 
											onMouseDown="this.src='../images/reviews/submit-button_click.png'" 
											onMouseUp="this.src='../images/reviews/submit-button_over.png'" />
											
										</td>
									</tr>
								</table>
							</form>
						</td>
					</tr>
				</table>

			</center>
			</div> <!-- reviewBoxContent -->
		</fieldset>
</div> <!-- reviewBox -->

	<div id="coverageChecker" title="" style="display:none;background-image:url(/plans/images/check-coverage-lightbox-back.jpg);background-repeat:no-repeat;">
		<center>
		<iframe src="http://www.wireless.att.com/coverageviewer/reseller-prepaid1.jsp" width="880px" height="750px" frameborder="0" scrolling="no" style="margin-top:100px;margin-left:10px;" marginwidth="0" marginheight="0"></iframe>
		</center>
	</div>
	
<div id="planpicker" title="" style="display:none;background-image:url(/catalog/images/wizards/plans/plans-page-background.jpg);background-repeat:no-repeat;">
	<div id='puPlanButton'>
		<img style='cursor:pointer;' 
			src='/catalog/images/refresh_2012/add-to-cart-button.png' alt="add to cart"
			onClick="doGetActivationType(<?= PLAN_PU_ID ?>, 'planpicker')" 
			onMouseOver="this.src='/catalog/images/refresh_2012/add-to-cart-button_over.png'" 
			onMouseOut="this.src='/catalog/images/refresh_2012/add-to-cart-button.png'" 
			onMouseDown="this.src='/catalog/images/refresh_2012/add-to-cart-button_click.png'" 
			onMouseUp="this.src='/catalog/images/refresh_2012/add-to-cart-button_over.png'" /><br>
	</div>
	<div id='buPlanButton'>
		<img style='cursor:pointer;' 
			src='/catalog/images/refresh_2012/add-to-cart-button.png' alt="add to cart"
			onClick="doGetActivationType(<?= PLAN_BU_ID ?>, 'planpicker')" 
			onMouseOver="this.src='/catalog/images/refresh_2012/add-to-cart-button_over.png'" 
			onMouseOut="this.src='/catalog/images/refresh_2012/add-to-cart-button.png'" 
			onMouseDown="this.src='/catalog/images/refresh_2012/add-to-cart-button_click.png'" 
			onMouseUp="this.src='/catalog/images/refresh_2012/add-to-cart-button_over.png'" /><br>
	</div>
	<div id='pfPlanButton'>
		<img style='cursor:pointer;' 
			src='/catalog/images/refresh_2012/add-to-cart-button.png' alt="add to cart"
			onClick="doGetActivationType(<?= PLAN_PF_ID ?>, 'planpicker')" 
			onMouseOver="this.src='/catalog/images/refresh_2012/add-to-cart-button_over.png'" 
			onMouseOut="this.src='/catalog/images/refresh_2012/add-to-cart-button.png'" 
			onMouseDown="this.src='/catalog/images/refresh_2012/add-to-cart-button_click.png'" 
			onMouseUp="this.src='/catalog/images/refresh_2012/add-to-cart-button_over.png'" /><br>
	</div>
	<div id='bfPlanButton'>
		<img style='cursor:pointer;' 
			src='/catalog/images/refresh_2012/add-to-cart-button.png' alt="add to cart"
			onClick="doGetActivationType(<?= PLAN_BF_ID ?>, 'planpicker')" 
			onMouseOver="this.src='/catalog/images/refresh_2012/add-to-cart-button_over.png'" 
			onMouseOut="this.src='/catalog/images/refresh_2012/add-to-cart-button.png'" 
			onMouseDown="this.src='/catalog/images/refresh_2012/add-to-cart-button_click.png'" 
			onMouseUp="this.src='/catalog/images/refresh_2012/add-to-cart-button_over.png'" /><br>
	</div>
	<div id='oneCallInfo'>
		Our oneCall Emergency Monitoring Service can be activated just by pressing the SOS button on the back of your <span class='snapName'>Snapf&#333;n</span> for 5 Seconds. 
		A trained and certified operator will answer your call on the first ring and greet you by name. Our professional operators have your emergency contact list and know who to dispatch in 
		case of trouble. We will even remain on the line with you until help arrives. No one else can be there for you 24 hours a day, 365 days a year. We are proud to be your lifeline.
	</div>
	<div id='protectionInfo'>
		We know that accidents happen. That's why we have included a unique protection package with our service. We will cover loss, theft, and many forms of physical damage including water, 
		and most things in between. There is no deductible, and we pay for shipping both ways. We want you to rely on your <span class='snapName'>Snapf&#333;n</span>, so we created a plan 
		that makes it a snap. We insure that you are covered, with no additional out of pocket expenses or inconveniences, because accidents do happen.
	</div>
</div>

<div id="activationpicker" title=""  style="display:none;background-image:url(/catalog/images/wizards/plans/activationTypeBackground.jpg);background-repeat:no-repeat;">
	<div id='activationpickertable'>
		<table width="100%">
			<tr>
				<td class='ezGreen beefy'>Phone Number Setup</td>
			</tr>
			<tr>
				<td>Do you need to transfer an existing number?</td>
			</tr>
			<tr>
				<td>
					<input type='radio' name='activationTypeCtl' id='activationTypePort' value="<?= ACTIVATION_FEE_PORT ?>"> Yes
					(<input type='text' class='numeric' name="portAreaCode" id="portAreaCode" value="" size="4" maxlength="3" />)
					<input type='text' class='numeric' name="portExchange" id="portExchange" value="" size="4" maxlength="3" />
					<input type='text' class='numeric' name="portNumber" id="portNumber" value="" size="5" maxlength="4" /><br>
					<span class="ezGreen">Number to be transferred</span>
				</td>
			</tr>
			<tr>
				<td>
					<input type='radio' name='activationTypeCtl' id='activationTypeNew' value="<?= ACTIVATION_FEE_NEW ?>" checked /> No, I need a new phone number.
				</td>
			</tr>
			<tr>
				<td>
					<img height="75%" id='activationPickerContinueButton' onclick='' 
						src='/catalog/images/refresh_2012/continue-button.png' alt="snapfon continue button"
						onmouseover='this.src="/catalog/images/refresh_2012/continue-button_over.png"' 
						onmouseout='this.src="/catalog/images/refresh_2012/continue-button.png"' 
						onmousedown='this.src="/catalog/images/refresh_2012/continue-button_click.png"' 
						onmouseup='this.src="/catalog/images/refresh_2012/continue-button_over.png"' />
				</td>
			</tr>
		</table>
	</div>
</div>

<div id="vidPlayer" title=""  style="text-align:center;display:none;background-image:url(/catalog/images/wizards/video-playback-background.jpg);background-repeat:no-repeat;">
	<div id='vidPlayerTable'>
		<script type="text/javascript">
			var params = { allowScriptAccess: "always" };
			var atts = { id: "myytplayer", styleclass: "playa" };
			swfobject.embedSWF("http://www.youtube.com/v/ASGbqVeAYDY?rel=0&enablejsapi=1&playerapiid=ytplayer&version=3",
							"vidPlayerTable", "425", "315", "8", null, null, params, atts);
		</script>
	</div>
</div>

	<div id="ezContactPicker" title=""  style="display:none;background-image:url(/catalog/images/wizards/ezcontact/add-ezcontact-wizard-lightbox-background.jpg);background-repeat:no-repeat;">
		<img id='ezContactYes' onclick=''
			src='/catalog/images/wizards/buttons/ezContact/add-to-cart-button.png' alt="Add ez Contact to cart"
			onmouseover='this.src="/catalog/images/wizards/buttons/ezContact/add-to-cart-button_over.png"'
			onmouseout='this.src="/catalog/images/wizards/buttons/ezContact/add-to-cart-button.png"'
			onmousedown='this.src="/catalog/images/wizards/buttons/ezContact/add-to-cart-button_click.png"'
			onmouseup='this.src="/catalog/images/wizards/buttons/ezContact/add-to-cart-button_over.png"' />

		<img id='ezContactNo' onclick=''
			src='/catalog/images/wizards/buttons/ezContact/no-thanks-button.png' alt="No Thanks"
			onmouseover='this.src="/catalog/images/wizards/buttons/ezContact/no-thanks-button_over.png"'
			onmouseout='this.src="/catalog/images/wizards/buttons/ezContact/no-thanks-button.png"'
			onmousedown='this.src="/catalog/images/wizards/buttons/ezContact/no-thanks-button_click.png"'
			onmouseup='this.src="/catalog/images/wizards/buttons/ezContact/no-thanks-button_over.png"' />

		<div id='ezContactPickertable' style="text-align: center;">
			<div id='ezVidPlayer'>
				<script type="text/javascript">
					var params = { allowScriptAccess: "always" };
					var atts = { id: "myezplayer", styleclass: "playa" };
					swfobject.embedSWF("http://www.youtube.com/v/ASGbqVeAYDY?rel=0&enablejsapi=1&playerapiid=ytplayer&version=3",
									"ezVidPlayer", "300", "187", "8", null, null, params, atts);
				</script>
			</div>
			<img id='ezPlayButton' onclick='myezplayer.playVideo()' style='cursor:pointer;'
				src='/catalog/images/wizards/buttons/ezContact/play-video-button.png' alt="No Thanks"
				onmouseover='this.src="/catalog/images/wizards/buttons/ezContact/play-video-button_over.png"'
				onmouseout='this.src="/catalog/images/wizards/buttons/ezContact/play-video-button.png"'
				onmousedown='this.src="/catalog/images/wizards/buttons/ezContact/play-video-button_click.png"'
				onmouseup='this.src="/catalog/images/wizards/buttons/ezContact/play-video-button_over.png"' />
		</div>
	</div>


</body>
</html>
